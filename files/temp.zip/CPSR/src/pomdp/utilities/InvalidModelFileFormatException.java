/*
 * Created on May 3, 2005
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package pomdp.utilities;

/**
 * @author shanigu
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class InvalidModelFileFormatException extends Exception {
	/**
	 * 
	 */
	public InvalidModelFileFormatException(){
		super();
	}
	public InvalidModelFileFormatException( String sData ){
		super( sData );
	}
}

package pomdp.utilities.concurrent;

import pomdp.utilities.Logger;

public class Lock {
	public Lock(){
		Logger.getInstance().logln( "Lock" );
	}
}

package pomdp.utilities;

public class HeuristicPolicy {
	public int getBestAction( int iState, BeliefState bsBelief ){
		return -1;
	}
	public int getObservation( int iStartState, int iAction, int iEndState ){
		return -1;
	}
	public int getNextState( int iState, int iAction ){
		return -1;
	}
}

/*
 *   Copyright 2012 William Hamilton
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 */

package cpsr.learning;

import java.util.HashMap;

import Jama.Matrix;
import Jama.QRDecomposition;
import cpsr.environment.components.ActionObservation;
import cpsr.learning.compression.RandomProjector;
import cpsr.learning.compression.SVD;
import cpsr.model.components.Mao;
import cpsr.model.components.Minf;
import cpsr.model.exceptions.PSRParameterException;

/**
 * Top-level class in learning package. 
 * Used for learning PSR representation.
 * 
 * @author William Hamilton
 */
public class Learner 
{
	private Matrix xth, ph, pseudoInverse, chXth, chPh;
	private HashMap<ActionObservation, Matrix> xtaohs;
	boolean pseudoInverseComputed, chComputed;
	RandomProjector chProjector;

	/**
	 * Constructor creates learning object from estimated observable matrices
	 *  
	 * @param xtaohs HashMap containing estimated and compressed Ptaoh matrices 
	 * @param xth Estimated and compressed Pth matrix
	 * @param ph Estimated Ph matrix
	 */
	public Learner(HashMap<ActionObservation, Matrix> xtaohs, Matrix xth, Matrix ph)
	{
		this.xth = xth;
		this.ph = ph;
		this.xtaohs = xtaohs;
		pseudoInverseComputed = false;
		chComputed = false;
	}
	
	public HashMap<ActionObservation, Mao> learnMaosWithRG()
	{
		if(!pseudoInverseComputed) computePseudoInverse();

		Matrix tempMat;
		HashMap<ActionObservation, Mao> Maos = new HashMap<ActionObservation, Mao>();
		for(ActionObservation o : xtaohs.keySet())
		{
			tempMat = chProjector.project(xtaohs.get(o).transpose()).times(pseudoInverse);
			Maos.put(o, new Mao(tempMat));
		}

		return Maos;
	}
	
	public Minf learnMinfWithRG()
	{
		if(!pseudoInverseComputed) computePseudoInverse();
		return new Minf((chPh.transpose().times(pseudoInverse)).transpose());
	}
	
	/**
	 * Computes psuedo inverse for learning.
	 */
	private void computePseudoInverse()
	{
		Matrix covar = chXth.transpose().times(chXth);
		SVD inverter = new SVD(covar.plus((Matrix.identity(covar.getRowDimension(), covar.getColumnDimension())).times(0.0)));
		pseudoInverse = inverter.getPseudoInverse();
		pseudoInverse = pseudoInverse.times(chXth.transpose());
		pseudoInverseComputed = true;
	}
	
	/**
	 * Computes compressed history (CH) observable matrices
	 */
	private void computeCHMats()
	{
		chProjector = new RandomProjector(xth.getRowDimension(), xth.getColumnDimension());
		chXth = chProjector.project(xth.transpose());
		chPh = chProjector.project(ph);
		chComputed = true;
	}
	
	/**
	 * Uses regression to learn Mao matrices
	 * 
	 * @return Hashmap of learned Mao matrices. 
	 */
	public HashMap<ActionObservation,Mao> learnMaosWithCH()
	{
		if(!chComputed)
		{
			computeCHMats();
			chComputed = true;
		}
		return learnMaosWithRG();
	}
	
	/**
	 * Uses regression to learn mInf matrix
	 * 
	 * @return Learned mInf matrix (vector) 
	 */
	public Minf learnMinfWithCH()
	{
		if(!chComputed)
		{
			computeCHMats();
			chComputed = true;
		}
		return learnMinfWithRG();
	}

	/**
	 * Uses regression to learn Mao matrices
	 * 
	 * @return Hashmap of learned Mao matrices. 
	 */
	public HashMap<ActionObservation,Mao> learnMaos()
	{

		Matrix tempMat;
		HashMap<ActionObservation, Mao> Maos = new HashMap<ActionObservation, Mao>();
		QRDecomposition regressor = new QRDecomposition(xth.transpose());

		for(ActionObservation o : xtaohs.keySet())
		{
			tempMat = regressor.solve(xtaohs.get(o).transpose());

			Maos.put(o, new Mao(tempMat.transpose()));
		}

		return Maos;
	}

	/**
	 * Uses regression to learn mInf matrix
	 * 
	 * @return Learned mInf matrix (vector) 
	 */
	public Minf learnMinf()
	{
		Matrix tempMatrix;
		QRDecomposition regressor = new QRDecomposition(xth.transpose());
		tempMatrix = regressor.solve(ph);
		Minf minf = null;
		try 
		{
			minf = new Minf(tempMatrix);
		}
		catch (PSRParameterException e) 
		{
			e.printStackTrace();
		}
		return minf;
	}

}

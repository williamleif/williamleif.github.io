/*
 *   Copyright 2012 William Hamilton
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 */

package cpsr.learning.compression;

import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import org.apache.commons.math3.linear.SingularValueDecomposition;
import Jama.Matrix;

/**
 * Class for performing SVD on matrices associated with PSRs.
 * Encapsulated the svd provided by apache.commons.math package  
 * 
 * @author William Hamilton
 */
public class SVD {
	private SingularValueDecomposition svd;

	 /**
	  * Constructor for SVD. Takes matrix and performs SVD on it.
	  * 
	  * @param m The matrix to perform SVD on. 
	  */
	public SVD(Matrix m)
	{
		svd = new SingularValueDecomposition(new Array2DRowRealMatrix(m.getArray()));		
	}
	
	
		/**
		 * Returns the matrix of left singular vectors U.
		 * Number of singular vectors retained is equal to dimension.
		 * 
		 * @param dimension Number of singular vectors retained.
		 * @return
		 */
		public Matrix getU(int dimension)
		{
			double[][] tempArray;
			Matrix u;
			tempArray = svd.getU().getData();
			u = new Matrix(tempArray);
			u = u.getMatrix(0, u.getRowDimension()-1, 0, dimension-1);
			
			return u;
		}
		
		public Matrix getPseudoInverse()
		{	
			 return new Matrix(svd.getSolver().getInverse().getData());	
		}
		
		/**
		 * Returns a array of singular values.
		 * Organized in decreasing order/ 
		 * 
		 * @return Array of singular values. 
		 */
		public double[] getSingularValues()
		{
			return svd.getSingularValues();
		}
}

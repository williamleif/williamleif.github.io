/*
 *   Copyright 2012 William Hamilton
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 */

package cpsr.learning.compression;

import java.util.Random;
import Jama.Matrix;
import org.apache.commons.math3.linear.SingularValueDecomposition;
import org.apache.commons.math3.linear.Array2DRowRealMatrix;

import cpsr.learning.exceptions.CompressionException;

/**
 * 
 * @author William Hamilton
 *
 * Class creates random projection matrix and can perform compression of matrices.
 */
public class RandomProjector {
	private Matrix phi;
	
	/**
	 * Initializes a random projection operator of specified size.
	 * Random entries drawn from Gaussian distribution. 
	 * 
	 * @param m The row dimension of random projection matrix (must be same as
	 * the column dimension of the matrix to be compressed).
	 * @param n The column dimension of random projection matrix (this is the 
	 * the compressed dimension; must be smaller than the row dimension of matrix 
	 * to be compressed.)
	 */
	public RandomProjector(int m, int n)
	{
		Random rand = new Random();
		if(m < 1) m = 1;
		phi = new Matrix(m, n);
		
		//setting entries to random numbers drawn from gaussian distrubution.
		for(int i = 0; i < m; i++)
		{
			for(int j = 0; j < n; j++)
			{
				phi.set(i,j, rand.nextGaussian()/(double)m);
			}
		}
	}
	
	/**
	 * Initializes a random projector operator to size of matrix
	 * passed as an argument.
	 *  
	 * @param mat Matrix used to specify row dimension of random projection operator. 
	 * @param n The column dimension of random projection matrix (this is the 
	 * the compressed dimension; must be smaller than that of matrix to be 
	 * compressed.)
	 */
	public RandomProjector(Matrix mat, int n)
	{
		int m = mat.getRowDimension();
		n = mat.getColumnDimension();
		
		Random rand = new Random();
		if(m < 1) m = 1;
		phi = new Matrix(m, n);
		
		//setting entries to random numbers drawn from gaussian distrubution.
		for(int i = 0; i < m; i++)
		{
			for(int j = 0; j < n; j++)
			{
				phi.set(i,j, rand.nextGaussian()/(double)m);
			}
		}
	}
	

	/**
	 * Method for compressing a matrix using random projections
	 * 
	 * @param mat The matrix to be compressed
	 * @return The compressed matrix. 
	 */
	public Matrix project(Matrix mat) 
	{
		/*if(mat.getColumnDimension() != phi.getRowDimension())
		{
			throw new CompressionException("Matrix does not have correct column dimension for compression");
		}*/
		return phi.times(mat);
	}
	
	/**
	 * Method for retrieving Jama matrix representation of random 
	 * projection operator
	 * 
	 * @return Matrix representation of random projection operator. 
	 */
	public Matrix getPhi()
	{
		//return Matrix.identity(phi.getRowDimension(), phi.getColumnDimension());
		return phi;
	}
	
	
}

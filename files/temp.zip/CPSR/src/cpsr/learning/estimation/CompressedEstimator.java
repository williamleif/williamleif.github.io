/*
 *   Copyright 2012 William Hamilton
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 */

package cpsr.learning.estimation;

import java.util.HashMap;
import java.util.ArrayList;

import cpsr.environment.DataSet;
import cpsr.environment.components.ActionObservation;
import cpsr.environment.components.IndicativeEvent;
import cpsr.learning.compression.RandomProjector;
import Jama.Matrix;

/**
 * Extension of Estimator class which performs estimation in compressed space
 * 
 * @author William Hamilton
 * @see Estimator  
 */
public class CompressedEstimator extends Estimator {
	Matrix phi;

	/**
	 * Parent of subclass must implement default constructor.
	 */
	public CompressedEstimator()
	{
		super();
	}
	/**
	 * Constructor 
	 * 
	 * @param data The data set used.
	 * @param proj The random projection object which specifies random projection matrix. 
	 */
	public CompressedEstimator(DataSet data, ArrayList<ArrayList<ActionObservation>> tests, 
			ArrayList<IndicativeEvent> indEvents, RandomProjector proj)
	{
		this.phi = proj.getPhi();
		this.data = data;
		this.indEvents = indEvents;
		this.tests = tests;
		
		//initializing observable matrices
		this.ph = new Matrix(indEvents.size()+1, 1);
		this.pth = new Matrix(phi.getRowDimension(), indEvents.size()+1);
		this.ptaohs = new HashMap<ActionObservation, Matrix>();
		for(ActionObservation o : data.getValidActionObservationSet())
		{
			if(!ptaohs.containsKey(o))
			{
				Matrix temp = new Matrix(phi.getRowDimension(), indEvents.size()+1);
				ptaohs.put(o, temp);
			}
		}
	}
		
	@Override
	protected void addPthCount(int ti, int hi)
	{
		if(ti != -1)
		{
			addColumn(ti, hi, pth);
		}
	}
	
	@Override
	protected void addPtaohCount(int toi, int hi, ActionObservation actob)
	{
		if(toi != -1) 
		{
			Matrix ptaohMat = ptaohs.get(actob);
			addColumn(toi, hi, ptaohMat);
		}
	}
	
	/**
	 * Helper method returns specified column (array of doubles) of projection matrix.
	 * Column corresponds to test.
	 * 
	 * @param j Index of column to return
	 * @return Array of doubles corresponding to specified column of projection matrix. 
	 */
	protected double[] getProjColumn(int j)
	{
		double[][] fullArray;
		double[] column;
		
		fullArray = phi.getMatrix(0, phi.getRowDimension()-1, j, j).transpose().getArrayCopy();
		column = fullArray[0];
		return column;
	}
	
	/**
	 * Helper method adds column to specified position of matrix.
	 * 
	 * @param testj The column to add from projection matrix
	 * @param histj Position where column is to be added
	 * @param mat Matrix which the column is being added to 
	 */
	protected void addColumn(int testj, int histj, Matrix mat)
	{
		double[] column = getProjColumn(testj);
		
		for(int i = 0; i < column.length; i++)
		{
			mat.set(i, histj, column[i]+mat.get(i, histj));
		}
		
	}

}

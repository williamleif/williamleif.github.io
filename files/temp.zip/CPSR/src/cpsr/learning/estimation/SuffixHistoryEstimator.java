/*
 *   Copyright 2012 William Hamilton
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 */
package cpsr.learning.estimation;

import java.util.ArrayList;

import cpsr.environment.DataSet;
import cpsr.environment.components.ActionObservation;
import cpsr.environment.components.IndicativeEvent;

/**
 * Class used to perform suffix history estimation.
 * 
 * @author William Hamilton
 */
public class SuffixHistoryEstimator extends Estimator 
{
	private int maxHistoryLength;

	public SuffixHistoryEstimator(DataSet data, ArrayList<ArrayList<ActionObservation>> tests, 
			ArrayList<IndicativeEvent> indEvents, int maxHistoryLength)
	{
		super(data, tests, indEvents);

		this.maxHistoryLength = maxHistoryLength;
	}

	@Override
	public void estimateObservableMatrices(int runs)
	{
		ArrayList<ActionObservation> currentSequence = new ArrayList<ActionObservation>();

		int resetCount = 0;

		//simulating run for specified number of iterations
		while(resetCount < runs)
		{
			currentSequence = data.getTrainingRun(resetCount);

			for(int i = 0; i < currentSequence.size(); i++)
			{
				for(int j = i+1; j < currentSequence.size()+1; j++)
				{
					ArrayList<ActionObservation> currentSequenceSublist = new ArrayList<ActionObservation>(currentSequence.subList(i, j));
					if(i == 0) 
					{
						setNullHistories(currentSequenceSublist);
					}

					parseAndAddCounts(currentSequenceSublist, 
							maxHistoryLength);
					incrementHistory(currentSequenceSublist);
				}
			}

			currentSequence = new ArrayList<ActionObservation>();

			//adding one to prob of null history
			ph.set(0, 0, ph.get(0, 0)+1);

			//incrementing reset count
			resetCount++;

		}
		normalize(resetCount);
	}
	
}

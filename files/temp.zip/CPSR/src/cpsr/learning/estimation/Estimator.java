/*
 *   Copyright 2012 William Hamilton
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 */

package cpsr.learning.estimation;

import java.util.HashMap;
import java.util.ArrayList;

import Jama.Matrix;
import cpsr.environment.DataSet;
import cpsr.environment.components.ActionObservation;
import cpsr.environment.components.IndicativeEvent;

/**
 * Estimator class is used to obtain empirical estimates from a DataSet.
 * 
 * @author William Hamilton
 */
public class Estimator {
	Matrix ph;
	Matrix pth;
	HashMap<ActionObservation, Matrix> ptaohs; 
	ArrayList<ArrayList<ActionObservation>> tests;
	ArrayList<IndicativeEvent> indEvents;
	DataSet data;

	public Estimator(){
		super();
	}

	/**
	 * Constructor which takes DataSet as argument.
	 * 
	 * @param data The DataSet.
	 * @param runs Number of runs to perform simulation for.  
	 */
	public Estimator(DataSet data, ArrayList<ArrayList<ActionObservation>> tests,
			ArrayList<IndicativeEvent> indEvents)
	{
		//initializing DataSet
		this.data = data;


		//getting indicative events and tests specified by DataSet
		this.indEvents = indEvents;
		this.tests = tests;

		//initializing observable matrices
		this.ph = new Matrix(indEvents.size()+1, 1);
		this.pth = new Matrix(tests.size(), indEvents.size()+1);
		this.ptaohs = new HashMap<ActionObservation, Matrix>();
		for(ActionObservation o : data.getValidActionObservationSet())
		{
			if(!ptaohs.containsKey(o))
			{
				Matrix temp = new Matrix(tests.size(), indEvents.size()+1);
				ptaohs.put(o, temp);
			}
		}
	}

	/**
	 * Method obtains empirical estimates by running trial runs through DataSet. 
	 * 
	 * @param runs Number of runs (i.e. trajectories) to perform during simulations
	 * (note that in some DataSets using to many runs will result in redundant 
	 * estimations). 
	 */
	public void estimateObservableMatrices(int runs)
	{
		ArrayList<ActionObservation> currentSequence = new ArrayList<ActionObservation>();

		int resetCount = 0;

		//simulating run for specified number of iterations
		while(resetCount < runs)
		{
			appendNextActionObservation(currentSequence);

			incrementHistory(currentSequence);

			setNullHistories(currentSequence);

			parseAndAddCounts(currentSequence);

			//checking if reset performed
			if(data.resetPerformed())
			{
				currentSequence = new ArrayList<ActionObservation>();
				//adding one to prob of null history
				ph.set(0, 0, ph.get(0, 0)+1);
				//incrementing reset count
				resetCount++;
			}
		}
		normalize(resetCount);
		
	}


	/**
	 * Helper method gets next action-observation pair
	 */
	protected void appendNextActionObservation(ArrayList<ActionObservation> currentSequence)
	{
		//getting next ActionObservation and adding to current sequence
		ActionObservation currentActionObservation = data.getNextActionObservation();
		currentSequence.add(currentActionObservation);
	}

	/**
	 * Helper method increments history count for this sequence
	 * 
	 * @param currentSequence The current sequence of action-observation pairs
	 */
	protected void incrementHistory(ArrayList<ActionObservation> currentSequence)
	{
		//incrementing history count for this sequence
		int hi = getIndexOfCurrentHistory(currentSequence)+1;
		if(hi != 0) ph.set(hi,0, ph.get(hi,0)+1);
	}

	/**
	 * Helper method sets the null history columns of observable matrices
	 * 
	 * @param currentSequence The current sequence of action-observation pairs.  
	 */
	protected void setNullHistories(ArrayList<ActionObservation>  currentSequence)
	{		
		addPthCount(tests.indexOf(currentSequence), 0);
		addPtaohCount(tests.indexOf(currentSequence.subList(1,currentSequence.size())), 0, currentSequence.get(0));
	}

	/**
	 * Helper method parses sequence into tests and histories and add counts
	 * 
	 * @param currentSequence The current sequence of action-observation pairs
	 */
	protected void parseAndAddCounts(ArrayList<ActionObservation> currentSequence)
	{
		parseAndAddCounts(currentSequence, Integer.MAX_VALUE);
	}
	
	/**
	 * Helper method parses sequence into tests and histories and add counts
	 * 
	 * @param currentSequence The current sequence of action-observation pairs
	 */
	protected void parseAndAddCounts(ArrayList<ActionObservation> currentSequence, int maxHistoryLength)
	{
		int hi;
		ArrayList<ActionObservation> currentHistory = new ArrayList<ActionObservation>();

		//looping through current sequence and parsing into possible sets of histories and tests
		for(int j = 0; j < currentSequence.size() && j < maxHistoryLength; j++)
		{
			//making history first part of current sequence
			currentHistory = new ArrayList<ActionObservation>(currentSequence.subList(0, j+1));
			hi = getIndexOfCurrentHistory(currentHistory)+1;

			if(j+1 < currentSequence.size())
			{
				addPthCount(tests.indexOf(currentSequence.subList(j+1, currentSequence.size())), hi);
			}
			
			if(j+2 < currentSequence.size())
			{
				addPtaohCount(tests.indexOf(currentSequence.subList(j+2, currentSequence.size())), hi, currentSequence.get(j+1));
			}
		
		}
	}

	/**
	 * Adds a pth count
	 * 
	 * @param ti test index
	 * @param hi history index
	 */
	protected void addPthCount(int ti, int hi)
	{
		if(ti != -1)
		{
			pth.set(ti,hi, pth.get(ti,hi)+1);
		}
	}

	/**
	 * Adds a ptaoh count
	 * 
	 * @param toi Test index.
	 * @param hi History index.
	 * @param actob Action Observation pair.
	 */
	protected void addPtaohCount(int toi, int hi, ActionObservation actob)
	{

		if(toi != -1)
		{
			Matrix ptaohMat = ptaohs.get(actob);
			ptaohMat.set(toi,hi, ptaohMat.get(toi, hi)+1);
		}
	}


	/**
	 * Helper method that gets index of current history
	 * 
	 * @param A ArrayList of action-observation pairs corresponding to a history
	 * @returns An integer representing the index of a history
	 */
	protected int getIndexOfCurrentHistory(ArrayList<ActionObservation> history)
	{
		int i = 0;
		for(IndicativeEvent event: indEvents)
		{
			if(event.contains(history)){
				return i;
			}
			i++;
		}
		return -1;
	}
	
	/**
	 * Normalizes the matrices by a factor
	 * 
	 * @param factor The factor.
	 */
	protected void normalize(int factor)
	{
		pth = pth.times(((double)(1.0/factor)));
		
		ph = ph.times(((double)(1.0/factor)));
		
		for(ActionObservation actob: ptaohs.keySet())
		{
			ptaohs.put(actob, ptaohs.get(actob).times(((double)(1.0/factor))));
		}
	}

	/**
	 * Returns the estimate of Ph matrix.
	 * 
	 * @return Estimate of Ph matrix
	 */
	public Matrix getPhEst()
	{
		return ph;
	}

	/**
	 * Returns estimate of Pth matrix
	 * 
	 * @return Estimate of Pth Matrix
	 */
	public Matrix getPthEst()
	{
		return pth;
	}

	/**
	 * Returns estimate of specified Ptaoh matrix
	 * 
	 * @param Action-observation pair corresponding to required Ptaoh matrix
	 * @return Requested Ptaoh matrix
	 */
	public Matrix getPtaohEst(ActionObservation ao)
	{
		return ptaohs.get(ao);
	}

	/**
	 * Returns HashMap containing all Ptaoh matrices, with keys corresponding to
	 * their action-observation pair.
	 * 
	 * @return HashMap containing all Ptaoh matrices, with keys corresponding to
	 * their action-observation pair.
	 */
	public HashMap<ActionObservation, Matrix> getPtaohsEst()
	{
		return ptaohs;
	}

}
/*
 *   Copyright 2013 William Hamilton
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 */
package cpsr.stats;

import cpsr.environment.DataSet;
import cpsr.environment.components.Action;
import cpsr.environment.components.ActionObservation;
import cpsr.environment.components.Observation;
import cpsr.model.IPSR;
import cpsr.model.IPredictor;

/**
 * Class for obtaining likelihood of DataSets given PSR models.
 * 
 * @author William Hamilton
 */
public class Likelihood 
{
	
	IPSR aPsr;
	DataSet aData;
	IPredictor aPredictor;

	/**
	 * Constructs a likelihood object given psr model data and predictor.
	 * 
	 * @param pPsr A PSR model.
	 * @param pData A DataSet.
	 * @param pPredictor A prediction object defined over the PSR model.
	 */
	public Likelihood(IPSR pPsr, DataSet pData, IPredictor pPredictor)
	{
		aPsr = pPsr;
		aData = pData;
		aPredictor = pPredictor;
	}

	/**
	 * @return The likelihood of data given the PSR model.
	 */
	public double getLikelihoodOfData()
	{
		double lLikelihood;
		
		lLikelihood = 0.0;
		for(int i = 0; i < aData.getMaxNumberOfRuns(); i++)
		{
			double lRunLike = 1.0;
			boolean firstStep = true;
			while(true)
			{
				if(firstStep)
				{
					firstStep = false;
				}
				else
				{
					if(checkForReset()) break;
				}
				lRunLike*=aPredictor.getImmediateProb(aData.getNextActionObservationForPlanning().getAction(),
						aData.getNextActionObservationForPlanning().getObservation());
	
			}
			lLikelihood+=lRunLike;
		}
		
		lLikelihood = lLikelihood/((double)aData.getMaxNumberOfRuns());
		
		return lLikelihood;
	}
	
	/**
	 * @return The likelihood of the first observations given the PSR model.
	 */
	public double getOneStepLikelihoodOfData()
	{
		double lLikelihood;
		
		lLikelihood = 0.0;
		for(int i = 0; i < aData.getMaxNumberOfRuns(); i++)
		{
				Action nextAct = aData.getNextActionObservationForPlanning().getAction();
				Observation nextObs = aData.getNextActionObservationForPlanning().getObservation();
				lLikelihood+=aPredictor.getImmediateProb(nextAct, nextObs);
				aPsr.update(new ActionObservation(nextAct, nextObs));
	
		}
		
		lLikelihood = lLikelihood/((double)aData.getMaxNumberOfRuns());
		
		return lLikelihood;
	}
	
	/**
	 * Helper method determines if a run terminated.
	 * If so, true returned and prediction vector reset. 
	 * 
	 * @return Boolean representing whether reset performed.
	 */
	private boolean checkForReset()
	{
		if(aData.resetPerformed())
		{
			aPsr.resetToStartState();
			return true;
		}
		else
		{
			return false;
		}
	}
}

package cpsr.stats;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

import cpsr.environment.components.Observation;
import cpsr.environment.obsonly.ObsOnlyDataSet;
import cpsr.environment.utils.IndicativeEventSetGenerator;
import cpsr.environment.utils.TestSetGenerator;
import cpsr.model.IPSR;
import cpsr.model.PSR;


public class GetSparsityInfo 
{
	public static void main(String args[])
	{
		try
		{
		BufferedReader reader = new BufferedReader(new FileReader("/home/2011/whamil3/10000runs.txt"));
		
		ArrayList<ArrayList<Observation>> obs = new ArrayList<ArrayList<Observation>>();
		obs.add(new ArrayList<Observation>());
		int count = 0;
		while(reader.ready())
		{
			int obsInt = Integer.parseInt(reader.readLine());
			if(obsInt == -1){
				count++;
				obs.add(new ArrayList<Observation>());
			}
			else
			{
				obs.get(count).add(new Observation(obsInt));
			}
		}
		
		ObsOnlyDataSet data = new ObsOnlyDataSet(obs);
		
		IndicativeEventSetGenerator indGen = new IndicativeEventSetGenerator(data);
		TestSetGenerator testGen = new TestSetGenerator(data);
		
		
		PSR psr = new PSR(data, testGen.generateTestSet(20), indGen.generateStandardIndicativeEvents(20), "CPSR", "Standard", 20);
		
		psr.build(1000, 1, 1);
		
		
		
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
}

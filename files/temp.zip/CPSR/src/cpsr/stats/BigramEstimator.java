/*
 *   Copyright 2012 William Hamilton
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 */
package cpsr.stats;
 
import java.util.ArrayList;
import java.util.HashMap;

import cpsr.environment.DataSet;
import cpsr.environment.components.ActionObservation;

/**
 * Class used to produce probability predictions using simple birgram
 * estimation.
 * 
 * @author William Hamilton
 */
public class BigramEstimator 
{
	protected DataSet dataSet;
	protected HashMap<ActionObservation, Double> singleCounts;
	protected HashMap<ArrayList<ActionObservation>, Double> bigramEstimates;
	
	/**
	 * Constructs a bigram estimator out of a data set.
	 * 
	 * @param dataSet The data set used.
	 */
	public BigramEstimator(DataSet dataSet)
	{
		this.dataSet = dataSet;
	}
	
	public void obtainEstimates()
	{
		intializeSingleCountList();
		bigramEstimates = new HashMap<ArrayList<ActionObservation>, Double>();
		
		for(int i = 0; i < dataSet.getMaxNumberOfRuns(); i++)
		{
			ArrayList<ActionObservation> run = dataSet.getTrainingRun(i);
			
			for(int j = 0; j < run.size()-1; j++)
			{
				singleCounts.put(run.get(j), singleCounts.get(run.get(j))+1);
				if(j != 0)
				{
					ArrayList<ActionObservation> pair = new ArrayList<ActionObservation>();
					pair.add(run.get(j-1));
					pair.add(run.get(j));
					if(!bigramEstimates.containsKey(pair))
					{
						bigramEstimates.put(pair, 0.0);
					}
					bigramEstimates.put(pair, bigramEstimates.get(pair)+1);
				}
			}
		}
		
	}
	
	/**
	 * Returns the probability of a bigram pair.
	 * @param pair 
	 * @return
	 */
	public double getProbability(ArrayList<ActionObservation> pair)
	{
		Double bigramCount = bigramEstimates.get(pair);
		
		if(bigramCount == null) return 0;
		
		return bigramCount/(singleCounts.get(pair.get(0)));
	}
	
	/**
	 * Intializes single count list.
	 */
	private void intializeSingleCountList()
	{
		singleCounts = new HashMap<ActionObservation, Double>();
		for(ActionObservation actob : dataSet.getValidActionObservationSet())
		{
			singleCounts.put(actob, 0.0);
		}
	}
}

package cpsr.stats;

import java.util.ArrayList;

import cpsr.environment.DataSet;

/**
 * Computes statistics relevant to planning.
 * 
 * @author William Hamilton
 */
public class PlanningStats
{

	public static double getAverageDiscountedReward(DataSet pData, double pDiscount)
	{
		double lAvReward = 0.0;
		double lRunReward;

		for(ArrayList<Double> lRewardVec : pData.getRewards())
		{
			lRunReward = 0;
			for(int i = 0; i < lRewardVec.size(); i++)
			{
				if(i == 0)
				{
					lRunReward+=lRewardVec.get(i);
				}
				else
				{
					lRunReward+=Math.pow(pDiscount, (double)i)*lRewardVec.get(i);
				}	
			}
			lAvReward+=lRunReward;
		}

		return lAvReward/((double)pData.getRewards().size());
	}

	public static double getVarOfDiscountedReward(DataSet pData, double pDiscount, double pAv)
	{		
		double lVar = 0.0;
		double lRunReward;

		for(ArrayList<Double> lRewardVec : pData.getRewards())
		{
			lRunReward = 0;
			for(int i = 0; i < lRewardVec.size(); i++)
			{
				if(i == 0)
				{
					lRunReward+=lRewardVec.get(i);
				}
				else
				{
					lRunReward+=Math.pow(pDiscount, (double)i)*lRewardVec.get(i);
				}	
			}
			lVar += Math.pow((lRunReward-pAv), 2);
		}

		return lVar/((double)pData.getRewards().size());
		
	}

	public static double getAverageLengthOfRun(DataSet pData)
	{
		ArrayList<Double> lLengthVec = new ArrayList<Double>();

		for(ArrayList<Double> pSingleRun : pData.getRewards())
		{
			lLengthVec.add((double)pSingleRun.size());
		}

		return Basic.mean(lLengthVec);
	}
}

///*
// *   Copyright 2012 William Hamilton
// *
// *   Licensed under the Apache License, Version 2.0 (the "License");
// *   you may not use this file except in compliance with the License.
// *   You may obtain a copy of the License at
// *
// *       http://www.apache.org/licenses/LICENSE-2.0
// *
// *   Unless required by applicable law or agreed to in writing, software
// *   distributed under the License is distributed on an "AS IS" BASIS,
// *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// *   See the License for the specific language governing permissions and
// *   limitations under the License.
// */
//package cpsr.stats;
//
//import java.io.BufferedReader;
//import java.io.BufferedWriter;
//import java.io.FileReader;
//import java.io.FileWriter;
//import java.io.IOException;
//import java.util.ArrayList;
//
//import Jama.Matrix;
//
///**
// * Class for writing k-step stats out for processing in matlab
// *
// * @author William Hamilton
// */
//public class KStepStats 
//{
//	
//	/**
//	 * 
//	 * @param k
//	 * @return
//	 */
//	private ArrayList<double[]> createKStepIdeals(int k)
//	{
//		double[] firstObDist = new double[1024];
//		ArrayList<double[]> dists = new ArrayList<double[]>();
//		firstObDist = getFirstObDist();
//		dists.add(firstObDist);
//
//		for(int i = 1; i < k; i++)
//		{
//			dists.add(new double[1024]);
//		}
//
//		try
//		{
//			BufferedReader reader = new BufferedReader(new FileReader(runFile));
//			int pos = 1;
//			int runCount = 0;
//			String runLine;
//			int obs;
//
//			while(reader.ready())
//			{
//				runLine = reader.readLine();
//				obs = Integer.parseInt(runLine);
//
//				if(obs == -1)
//				{
//					pos = 0;
//					reader.readLine();
//					runCount++;
//				}
//				else if(pos < k)
//				{
//					double[] temp = dists.get(pos);
//					temp[obs] = temp[obs] + 1;
//				}
//				pos++;
//			}
//			System.out.println(runCount);
//
//			boolean first = true;
//			for(double[] obsDist : dists)
//			{
//				if(!first)
//				{
//					for(int i = 0; i < 1024; i++)
//					{
//						obsDist[i] = obsDist[i]/((double)runCount);
//					}
//				}
//				first = false;
//			}	
//		}
//		catch(IOException ex)
//		{
//			ex.printStackTrace();
//		}
//
//		return dists;
//	}
//	
//	/**
//	 * Helper method for writing stats out to file
//	 * 
//	 * @param ideals Ideal predictions.
//	 * @param actuals Actual predictions.
//	 * @param outfile File to write to. 
//	 */
//	private void writeKStepStats(ArrayList<double[]> ideals, ArrayList<double[]> actuals, String outfile)
//	{
//		ArrayList<Double> errs = new ArrayList<Double>();
//
//		for(int i = 0; i < ideals.size(); i++)
//		{
//			Matrix diffVector = new Matrix(1024, 1);
//			double[][] tempArray1 = new double[1][1024];
//			double[][] tempArray2 = new double[1][1024];
//
//			tempArray1[0] = actuals.get(i);
//			tempArray2[0] = ideals.get(i);
//
//			Matrix tempMatrix1 = new Matrix(tempArray1);
//			Matrix tempMatrix2 = new Matrix(tempArray2);
//			tempMatrix1 = tempMatrix1.transpose();
//			tempMatrix2 = tempMatrix2.transpose();
//
//			diffVector = tempMatrix1.minus(tempMatrix2);
//			errs.add(diffVector.norm2());
//		}
//
//		try
//		{
//			BufferedWriter writer = new BufferedWriter(new FileWriter(outfile, true));
//
//			for(int i = 0; i < errs.size(); i++)
//			{
//				writer.write(Double.toString(errs.get(i)));
//				writer.write(" ");
//			}
//			writer.newLine();
//
//			writer.close();
//
//		}
//		catch(IOException ex)
//		{
//			ex.printStackTrace();
//		}
//	}
//	
//	/**
//	 * Helper method gets probability predictions made by PSR.
//	 * 
//	 * @param actualFile File with predictions
//	 * @return Processed vector of array of predictions
//	 */
//	private ArrayList<double[]> getKStepActuals(String actualFile)
//	{
//		ArrayList<double[]> actualDists = new ArrayList<double[]>();
//
//		try
//		{
//			BufferedReader reader = new BufferedReader(new FileReader(actualFile));
//			int pos = 0;
//			double prob;
//			reader.readLine();
//			while(reader.ready())
//			{
//				double[] obDist = new double[1024];
//
//				for(int i = 0; i < 1024; i++)
//				{
//					try{
//						prob = Double.parseDouble(reader.readLine());
//					}
//					catch(NumberFormatException ex)
//					{
//						prob = 0.0;
//					}
//					prob = prob < 0 ? 0 : prob;
//					prob = prob > 1 ? 1 : prob;
//					obDist[i] = prob;
//				}
//
//				actualDists.add(obDist);
//				reader.readLine();
//			}
//		}
//		catch(IOException ex)
//		{
//			ex.printStackTrace();
//		}
//
//		return actualDists;
//	}
//}

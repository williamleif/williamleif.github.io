package cpsr.model;

import java.util.HashSet;

import cpsr.environment.DataSet;
import cpsr.environment.components.Action;
import cpsr.environment.components.ActionObservation;
import cpsr.model.components.PredictionVector;

public interface IPSR {

	/**
	 * Returns boolean specifying whether the PSR has been built.
	 * 
	 * @return Boolean specifying whether the PSR has been built. 
	 */
	public abstract boolean isBuilt();

	/**
	 * Returns DataSet associated with the PSR.
	 * 
	 * @return DataSet associated with the PSR. 
	 */
	public abstract DataSet getDataSet();

	/**
	 * Updates the PSR representation using action-observation pair. 
	 * 
	 * @param ao Action-observation pair used in update
	 */
	public abstract void update(ActionObservation ao);

	/**
	 * Resets PSR to start state.
	 */
	public abstract void resetToStartState();

	/**
	 * Returns action Set
	 * 
	 * @return Set of valid actions.
	 */
	public abstract HashSet<Action> getActionSet();


}
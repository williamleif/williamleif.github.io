/*
 *   Copyright 2012 William Hamilton
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 */

package cpsr.model;

import java.util.ArrayList;
import java.util.HashMap;

import Jama.Matrix;
import cpsr.environment.components.Action;
import cpsr.environment.components.ActionObservation;
import cpsr.environment.components.Observation;
import cpsr.model.components.Mao;
import cpsr.model.exceptions.PSRRuntimeException;

/**
 * Class defines methods used to perform prediction with PSR representation. 
 * 
 * @author William Hamilton
 */
public class Predictor implements IPredictor 
{
	protected PSR psr;

	boolean mStarCreated;
	Matrix mStar;

	/**
	 * Default constructor for inheritance
	 */
	public Predictor()
	{
		super();
	}
	
	/**
	 * Creates prediction object using specified PSR.
	 * 
	 * @param psr PSR representation to be used in prediction. 
	 */
	public Predictor(PSR psr)
	{
		this.psr = psr;
		mStarCreated = false;
		mStar = null;
	}

	/* (non-Javadoc)
	 * @see cpsr.model.IPredictor#getImmediateProb(cpsr.environment.components.Action, cpsr.environment.components.Observation)
	 */
	@Override
	public double getImmediateProb(Action act, Observation ob)
	{
		ActionObservation actob = new ActionObservation(act, ob);
		ArrayList<ActionObservation> test = new ArrayList<ActionObservation>();
		test.add(actob);

		Matrix testParam = computeTestParameter(test);

		double prob = testParam.times(psr.getPredictionVector().getVector()).get(0,0);
		
		if(prob > 1.0) prob = 1.0;
		if(prob < 0.0) prob = 0.0;
		return prob;
	}

	/* (non-Javadoc)
	 * @see cpsr.model.IPredictor#getImmediateProb(java.util.ArrayList, java.util.ArrayList)
	 */
	@Override
	public double getImmediateProb(ArrayList<Action> acts, ArrayList<Observation> obs)
	{
		ArrayList<ActionObservation> test = createTestFromActionObservationLists(acts, obs);

		Matrix testParam = computeTestParameter(test);
		
		double prob = testParam.times(psr.getPredictionVector().getVector()).get(0,0);
		if(prob > 1.0) prob = 1.0;
		if(prob < 0.0) prob = 0.0;
		return prob;
	}

	/* (non-Javadoc)
	 * @see cpsr.model.IPredictor#getKStepPredictionProb(cpsr.environment.components.Action, cpsr.environment.components.Observation, int)
	 */
	@Override
	public double getKStepPredictionProb(Action act, Observation ob, int k)
	{
		act.setData(this.psr.getDataSet());
		ob.setData(this.psr.getDataSet());
		ActionObservation actob = new ActionObservation(act, ob);
		ArrayList<ActionObservation> test = new ArrayList<ActionObservation>();
		test.add(actob);

		if(!mStarCreated) createMStar();

		Matrix mStarCopy;
		if(k < 0)
		{
			throw new PSRRuntimeException("Cannot predict into the past, use valid k");
		}
		else if (k == 0)
		{
			mStarCopy = Matrix.identity(mStar.getRowDimension(), mStar.getColumnDimension());
		}
		else
		{
			mStarCopy = raiseMStarToPower(k);

		}
			
		Matrix tempMatrix = computeTestParameter(test);

		tempMatrix = tempMatrix.times(mStarCopy);
		double prob = tempMatrix.times(psr.getPredictionVector().getVector()).get(0,0);
		if(prob > 1.0) prob = 1.0;
		if(prob < 0.0) prob = 0.0;
		return prob;
		
	}

	/* (non-Javadoc)
	 * @see cpsr.model.IPredictor#getKStepPredictionProb(java.util.ArrayList, java.util.ArrayList, int)
	 */
	@Override
	public double getKStepPredictionProb(ArrayList<Action> acts, ArrayList<Observation> obs, int k)
	{
		ArrayList<ActionObservation> test = createTestFromActionObservationLists(acts, obs);

		if(!mStarCreated) createMStar();
		
		Matrix mStarCopy;
		if(k < 0)
		{
			throw new PSRRuntimeException("Cannot predict into the past, use valid k");
		}
		else if (k == 0)
		{
			mStarCopy = Matrix.identity(mStar.getRowDimension(), mStar.getColumnDimension());
		}
		else
		{
			mStarCopy = raiseMStarToPower(k);

		}

		Matrix tempMatrix = computeTestParameter(test);

		tempMatrix = tempMatrix.times(mStarCopy);

		double prob =  tempMatrix.times(psr.getPredictionVector().getVector()).get(0,0);
		if(prob > 1.0) prob = 1.0;
		if(prob < 0.0) prob = 0.0;
		return prob;
		
	}

	/**
	 * Helper method computes the MStar parameter.
	 * 
	 */
	private void createMStar()
	{
		mStar = null;
		HashMap<ActionObservation, Mao> maos = psr.getMaos();

		boolean firstIt = true;
		for(Mao mao  : maos.values())
		{
			if(firstIt)
			{
				mStar = mao.getMatrix().copy();
			}
			else
			{
				mStar = mStar.plus(mao.getMatrix());
			}
			firstIt = false;
		}
		mStarCreated = true;
	}

	/**
	 * Helper method returns MStar raised to specified power. 
	 * 
	 * @param k The power to which MStar is raised. 
	 * @return MStar raised to specified power. 
	 */
	private Matrix raiseMStarToPower(int k)
	{
		Matrix mStarCopy = mStar.copy();
		for(int i = 1; i < k ; i++)
		{
			mStarCopy = mStar.times(mStarCopy);
		}

		return mStarCopy;
	}

	/**
	 * Helper method computes the matrix parameter associated with a test. 
	 * 
	 * @param test The test which we want the parameter for.
	 * @return The parameter associated with the test. 
	 */
	private Matrix computeTestParameter(ArrayList<ActionObservation> test)
	{
		int length = test.size();
		Mao tempMao = null;
		Matrix tempMatrix = null;

		try
		{
			tempMao = psr.getMao(test.get(0));
			tempMatrix = tempMao.getMatrix();
			for(int i = length - 1; i > 0; i--)
			{
				tempMatrix = tempMatrix.times(psr.getMao(test.get(i)).getMatrix());
			}
			tempMatrix = psr.getMinf().getVector().transpose().times(tempMatrix);
		}
		catch(PSRRuntimeException ex)
		{
			ex.printStackTrace();
			tempMatrix = new Matrix(1, psr.getMinf().getVector().getRowDimension());
		}
		
		return tempMatrix;
	}

	/**
	 * Helper method creates test from seperate lists of actions and observations.
	 * 
	 * @param acts List of actions. 
	 * @param obs List of observations.
	 * @return Vector representing test formed by combining action and observation
	 * list in order. 
	 * @throws  
	 */
	private ArrayList<ActionObservation> createTestFromActionObservationLists(ArrayList<Action> acts, ArrayList<Observation> obs) 
	{
		if(acts.size() != obs.size())
		{
			try
			{
				throw new PSRRuntimeException("Tests for prediction must have equal number of actions and observations");
			}
			catch(PSRRuntimeException ex)
			{
				ex.printStackTrace();
			}
		}

		int i = 0;
		ActionObservation actobentry = null;
		ArrayList<ActionObservation> test = new ArrayList<ActionObservation>();
		for(Action act : acts)
		{
			act.setData(this.psr.getDataSet());
			actobentry = new ActionObservation(act, obs.get(i));
			i++;
			test.add(actobentry);
		}
		return test;
	}
}

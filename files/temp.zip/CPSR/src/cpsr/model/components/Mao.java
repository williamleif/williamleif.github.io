/*
 *   Copyright 2012 William Hamilton
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 */

package cpsr.model.components;
import java.io.Serializable;
import Jama.Matrix;

/**
 * Mao class is used to encapsulate matrices representing Mao parameters of PSR.
 * The encapsulation restricts access and functionality. 
 * 
 * @author whamil3
 *
 */
@SuppressWarnings("serial")
public class Mao implements Serializable {

	/**
	 * @serialField
	 */
	private Matrix matrix;

	/**
	 * Initialises an Mao parameter matrix of specified size with
	 * entries equal to zero.
	 * 
	 * @param m The row dimension.
	 * @param n The column dimension. 
	 */
	public Mao(int m, int  n)
	{
		matrix = new Matrix(m,n);
	}

	/**
	 * Creates a Mao parameter matrix by deep copying matrix passed as parameter.
	 * 
	 * @param matrix The matrix that will be copied as an Mao parameter. 
	 */
	public Mao(Matrix matrix)
	{
		this.matrix = matrix.copy();
	}

	/**
	 * Retrieves an entry from Mao parameter matrix. 
	 * 
	 * @param i The row index of entry.
	 * @param j The column index of entry.
	 * @return The specified entry. 
	 */
	public double getEntry(int i, int j)
	{
		return matrix.get(i, j);
	}

	/**
	 * Returns deep copy of Mao parameter form in standard matrix format. 
	 * 
	 * @return Mao parameter matrix. 
	 */
	public Matrix getMatrix()
	{
		return matrix.copy();
	}

	/**
	 * Used to set specifec entry in matrix. 
	 * 
	 * @param i Row index of entry.
	 * @param j Column index of entry. 
	 * @param value The value used to set entry. 
	 */
	public void setEntry(int i,int j, double value)
	{
		matrix.set(i,j, value);
	}
}



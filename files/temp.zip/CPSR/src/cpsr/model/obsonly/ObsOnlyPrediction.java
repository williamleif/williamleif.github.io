package cpsr.model.obsonly;

import java.util.ArrayList;

import cpsr.environment.components.Action;
import cpsr.environment.components.Observation;
import cpsr.environment.exceptions.EnvironmentException;
import cpsr.environment.obsonly.DummyAction;
import cpsr.model.PSR;
import cpsr.model.Predictor;

/**
 * Class for performing observation-only prediction (i.e. HMM style).
 * 
 * @author William Hamilton
 */
public class ObsOnlyPrediction extends Predictor 
{
	/**
	 * Constructs observation only predictor from PSR.
	 * 
	 * @param PSR representation used for prediction.
	 */
	public ObsOnlyPrediction(PSR psr)
	{
		super(psr);
		
		//safety check
		if(!psr.getDataSet().getClass().toString().equals("class cpsr.environment.obsonly.ObsOnlyDataSet"))
		{
			throw new EnvironmentException("Observation only prediction must be done with observation only dataset");
		}
	}
	
	/**
	 * Returns the probability of an observation occurring at the
	 * next time step.
	 * 
	 * @param ob The observation.
	 * @return The probability of the observation occurring.
	 */
	public double getImmediateProb(Observation ob)
	{
		return super.getImmediateProb(new DummyAction(this.psr.getDataSet()), ob);
	}
	
	/**
	 * Returns the probability of a sequence of observations occurring at the
	 * next time step.
	 * 
	 * @param obs The sequence of observations.
	 * @return The probability of the sequence occurring.
	 * */
	public double getImmediateProb(ArrayList<Observation> obs)
	{
		ArrayList<Action> dummys = createDummys(obs.size());
		
		return super.getImmediateProb(dummys, obs);
	}
	
	@Override
	public double getImmediateProb(Action act, Observation ob)
	{
		checkAction(act);
		return super.getImmediateProb(act, ob);
	}
	
	@Override
	public double getImmediateProb(ArrayList<Action> acts, ArrayList<Observation> obs)
	{
		for(Action act : acts)
		{
			checkAction(act);
		}
		return super.getImmediateProb(acts, obs);
	}
	
	/**
	 * Returns k-step prediction for an observation
	 * 
	 * @param ob
	 * @param k
	 * @return
	 */
	public double getKStepPredictionProb(Observation ob, int k)
	{
		return super.getKStepPredictionProb(new DummyAction(this.psr.getDataSet()), ob, k);
	}
	
	/**
	 * Returns k-step prediction for sequence of observations
	 * 
	 * @param obs
	 * @param k
	 * @return
	 */
	public double getKStepPredictionProb(ArrayList<Observation> obs, int k)
	{
		ArrayList<Action> dummys = createDummys(obs.size());
		
		return super.getKStepPredictionProb(dummys, obs, k);
	}
	
	/**
	 * Creates dummy list of actions.
	 * 
	 * @param size Size of list.
	 * @return Dummy list.
	 */
	private ArrayList<Action> createDummys(int size)
	{
		ArrayList<Action> dummys = new ArrayList<Action>();
		
		for(int i = 0; i < size; i++)
		{
			dummys.add(new DummyAction(this.psr.getDataSet()));
		}
		
		return dummys;
	}
	
	/**
	 * Ensures that an action is a DummyAction
	 * 
	 * @param act The action.
	 */
	private void checkAction(Action act)
	{
		if(!act.getClass().toString().equals("class cpsr.environments.obsonly.DummyAction"))
		{
			throw new EnvironmentException("Observation only prediction can only be done in observation only environments that" +
					"use the DummyAction placeholder");
		}
	}
	
	
}

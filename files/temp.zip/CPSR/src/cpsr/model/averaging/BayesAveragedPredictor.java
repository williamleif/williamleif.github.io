package cpsr.model.averaging;

import java.util.ArrayList;

import cpsr.environment.components.Action;
import cpsr.environment.components.Observation;
import cpsr.model.IPredictor;
import cpsr.model.PSR;
import cpsr.model.Predictor;

public class BayesAveragedPredictor implements IPredictor {

	private ArrayList<PSR> aPSRs;
	private ArrayList<Double> aWeights;
	
	public BayesAveragedPredictor(BayesAveragedPSR pBPSR)
	{
		aPSRs = pBPSR.getPSRs();
		aWeights = pBPSR.getWeights();
	}
	
	@Override
	public double getImmediateProb(Action act, Observation ob) 
	{
		double lProb = 0;
		
		int i = 0;
		for(PSR lPSR : aPSRs)
		{
			lProb+=(new Predictor(lPSR)).getImmediateProb(act, ob)*aWeights.get(i);
			i++;
		}
		return lProb;
	}

	@Override
	public double getImmediateProb(ArrayList<Action> acts,
			ArrayList<Observation> obs) {
		double lProb = 0;
		int i = 0;
		for(PSR lPSR : aPSRs)
		{
			lProb+=(new Predictor(lPSR)).getImmediateProb(acts, obs)*aWeights.get(i);
			i++;
		}
		return lProb;
	}

	@Override
	public double getKStepPredictionProb(Action act, Observation ob, int k) {
		double lProb = 0;
		int i = 0;
		for(PSR lPSR : aPSRs)
		{
			lProb+=(new Predictor(lPSR)).getKStepPredictionProb(act, ob, k)*aWeights.get(i);
			i++;
		}
		return lProb;
	}

	@Override
	public double getKStepPredictionProb(ArrayList<Action> acts,
			ArrayList<Observation> obs, int k) {
		double lProb = 0;
		int i = 0;
		for(PSR lPSR : aPSRs)
		{
			lProb+=(new Predictor(lPSR)).getKStepPredictionProb(acts, obs, k)*aWeights.get(i);
			i++;
		}
		return lProb;
	}

}

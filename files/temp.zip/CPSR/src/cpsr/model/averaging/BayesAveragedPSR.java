package cpsr.model.averaging;

import java.util.ArrayList;
import java.util.HashSet;

import Jama.Matrix;
import cpsr.environment.DataSet;
import cpsr.environment.components.Action;
import cpsr.environment.components.ActionObservation;
import cpsr.environment.components.IndicativeEvent;
import cpsr.model.IPSR;
import cpsr.model.PSR;
import cpsr.model.Predictor;
import cpsr.model.components.PredictionVector;
import cpsr.model.exceptions.PSRBuildException;
import cpsr.stats.Likelihood;

public class BayesAveragedPSR implements IPSR {

	ArrayList<PSR> aPSRs;
	
	ArrayList<Double> weights;

	/**
	 * @serialField
	 */
	private DataSet data;

	/**
	 * @serialField
	 */
	private String historyType;

	/**
	 * @serialField
	 */
	private int maxHistoryLength;

	/**
	 * @serialField
	 */
	private ArrayList<ArrayList<ActionObservation>> tests;

	/**
	 * @serialField
	 */
	private ArrayList<IndicativeEvent> indEvents;

	private boolean built;
	
	/**
	 * Constructor initializes Bayes averged PSR of specified psrType with DataSet 
	 * 
	 * @param data The DataSet which the PSR is used to model.
	 * @param tests The tests used in the model.
	 * @param indEvents The indicative events used in the model.
	 * @param historyType Either "Standard" (for domains with reset) or "Suffix" for
	 * domains without reset.
	 * @param maxHistoryLength Max suffix history length.
	 * Ignored if using standard histories
	 */
	public BayesAveragedPSR(DataSet data, ArrayList<ArrayList<ActionObservation>> tests, ArrayList<IndicativeEvent> indEvents,
			String historyType, int maxHistoryLength)
	{
		this.data = data;

		this.indEvents = indEvents;
		this.tests = tests;
		this.historyType = historyType;
		this.maxHistoryLength = maxHistoryLength;
	}
	
	public void build(int runs, ArrayList<Integer> projDims, ArrayList<Integer> svdDims, ArrayList<Double> priors)
	{
		if(!(svdDims.size() == 0) && projDims.size() != svdDims.size())
		{
			throw new PSRBuildException("Number of SVD dimensions must be 0 or equal to number of projDimension");
		}
		
		weights = new ArrayList<Double>();
		aPSRs = new ArrayList<PSR>();
		ArrayList<Double> likes = new ArrayList<Double>();
		for(int i = 0; i < projDims.size(); i++)
		{
			if(svdDims.size() == 0)
			{
				aPSRs.add(new PSR(data, tests, indEvents, "CPSR", "Standard", maxHistoryLength));
				aPSRs.get(i).build(runs, projDims.get(i), 0);
			}
			else
			{
				aPSRs.add(new PSR(data, tests, indEvents, "Combined", "Standard", maxHistoryLength));
				aPSRs.get(i).build(runs, projDims.get(i), svdDims.get(i));
			}
			Likelihood liker = new Likelihood(aPSRs.get(i),data, new Predictor(aPSRs.get(i)));
			likes.add(liker.getLikelihoodOfData());
		}
		
		double weightSum = 0.0;
		double currWeight;
		for(int i = 0; i < aPSRs.size(); i++)
		{
			currWeight = likes.get(i)*priors.get(i);
			weightSum += currWeight;
			weights.add(currWeight);
		}
		
		for(int i = 0; i < weights.size(); i++)
		{
			weights.set(i, weights.get(i)/weightSum);
		}
		
		built = true;

	}

	@Override
	public boolean isBuilt() {
		return built;
	}

	@Override
	public DataSet getDataSet() 
	{
		return data;
	}

	@Override
	public void update(ActionObservation ao)
	{
		for(PSR lPSR : aPSRs)
		{
			lPSR.update(ao);
		}
	}

	@Override
	public void resetToStartState()
	{
		for(PSR lPSR : aPSRs)
		{
			lPSR.resetToStartState();
		}
	}

	@Override
	public HashSet<Action> getActionSet() 
	{
		return aPSRs.get(0).getActionSet();
	}
	
	public ArrayList<PSR> getPSRs()
	{
		return aPSRs;
	}
	
	public ArrayList<Double> getWeights()
	{
		return weights;
	}

}

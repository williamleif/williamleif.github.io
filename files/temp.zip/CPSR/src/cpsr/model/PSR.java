/*
 *   Copyright 2012 William Hamilton
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 */

package cpsr.model;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import Jama.Matrix;
import cpsr.environment.DataSet;
import cpsr.environment.components.Action;
import cpsr.environment.components.ActionObservation;
import cpsr.environment.components.IndicativeEvent;
import cpsr.learning.Learner;
import cpsr.learning.compression.RandomProjector;
import cpsr.learning.compression.SVD;
import cpsr.learning.estimation.CompressedEstimator;
import cpsr.learning.estimation.CompressedSuffixHistoryEstimator;
import cpsr.learning.estimation.Estimator;
import cpsr.learning.estimation.SuffixHistoryEstimator;
import cpsr.model.components.Mao;
import cpsr.model.components.Minf;
import cpsr.model.components.PredictionVector;
import cpsr.model.exceptions.PSRBuildException;
import cpsr.model.exceptions.PSRParameterException;
import cpsr.model.exceptions.PSRRuntimeException;
import cpsr.model.exceptions.PVException;

/**
 * Top-level class for learning and maintaining a PSR.
 * 
 * @author William Hamilton
 */
@SuppressWarnings("serial")
public class PSR implements Serializable, IPSR
{
	/**
	 * @serialField
	 */
	private PredictionVector pv, initialPv;

	/**
	 * @serialField
	 */
	private DataSet data;

	/**
	 * @serialField
	 */
	private String psrType, historyType;

	/**
	 * @serialField
	 */
	private int maxHistoryLength;


	private transient Matrix phEst, xth;

	private transient HashMap<ActionObservation, Matrix> xthos;

	/**
	 * @serialField
	 */
	private HashMap<ActionObservation, Mao> maos;

	/**
	 * @serialField
	 */
	private Minf mInf;

	/**
	 * @serialField
	 */
	private ArrayList<ArrayList<ActionObservation>> tests;

	/**
	 * @serialField
	 */
	private ArrayList<IndicativeEvent> indEvents;

	private boolean built;
	
	private transient Learner learner;


	/**
	 * Constructor initializes PSR of specified psrType with DataSet 
	 * 
	 * @param data The DataSet which the PSR is used to model.
	 * @param tests The tests used in the model.
	 * @param indEvents The indicative events used in the model.
	 * @param psrType The psrType of PSR (TPSR, CPSR, Combined). 
	 * @param historyType Either "Standard" (for domains with reset) or "Suffix" for
	 * domains without reset.
	 * @param maxHistoryLength Max suffix history length.
	 * Ignored if using standard histories
	 */
	public PSR(DataSet data, ArrayList<ArrayList<ActionObservation>> tests, ArrayList<IndicativeEvent> indEvents, String psrType,
			String historyType, int maxHistoryLength)
	{
		this.data = data;

		this.indEvents = indEvents;
		this.tests = tests;

		this.psrType = psrType;
		this.historyType = historyType;
		this.maxHistoryLength = maxHistoryLength;
	}
	
	/**
	 * Constructor initializes PSR of specified psrType with DataSet 
	 * 
	 * @param data The DataSet which the PSR is used to model.
	 * @param tests The tests used in the model.
	 * @param indEvents The indicative events used in the model.
	 * @param psrType The psrType of PSR (TPSR, CPSR, Combined). 
	 * @param historyType Either "Standard" (for domains with reset) or "Suffix" for
	 * domains without reset.
	 * @param maxHistoryLength Max history length.
	 */
	public PSR(DataSet data, ArrayList<ArrayList<ActionObservation>> tests, ArrayList<IndicativeEvent> indEvents, String psrType)
	{
		this.data = data;

		this.indEvents = indEvents;
		this.tests = tests;

		this.psrType = psrType;
		this.historyType = "Standard";
		this.maxHistoryLength = -1;
	}

	/**
	 * Builds a PSR representation.
	 * 
	 * @param runs Number of runs to use in estimation.
	 * @param randomProjectionDim Random projection dimension (0 if psrType TPSR).
	 * @param svdDim Number of singular vectors to keep (0 if psrType CPSR).
	 */
	public void build(int runs, int randomProjectionDim, int svdDim)
	{

		if(psrType.equals("CPSR") || psrType.equals("Combined"))
		{
			learnInCompressedSpace(runs, randomProjectionDim, svdDim);

		}else if(psrType.equals("TPSR"))
		{
			estimateInOriginalSpace(runs);
			performSVD(svdDim);
			//initializing learner
			learner = new Learner(xthos, xth, phEst);
			//computing parameters
			maos = learner.learnMaos();
			mInf = learner.learnMinf();
		}
		else
		{
			throw new PSRBuildException("Invalid psrType: psrType must be one CPSR, TPSR, or Combined");
		}

		//System.out.println("Finished learning PSR parameters");

		try
		{
			if(historyType.equals("Standard"))
			{
			pv = new PredictionVector(xth.getMatrix(0,xth.getRowDimension()-1,0,0));
			}
			else
			{
				pv = new PredictionVector(xth.times(Matrix.identity(xth.getColumnDimension(), 1)));
			}
			initialPv = new PredictionVector(pv.getVector());
		}
		catch(PVException ex)
		{
			ex.printStackTrace();
		}

		built = true;
	}

	/**
	 * Performs estimation of parameters in compressed space. 
	 * 
	 * @param runs Number of runs in estimation. 
	 * @param randomProjectionDim Random projection dimension.
	 */
	private void estimateInCompressedSpace(int runs, int randomProjectionDim)
	{

		RandomProjector proj = new RandomProjector(randomProjectionDim, tests.size());
		CompressedEstimator estimator = null;

		//getting estimates
		if(historyType.equals("Standard"))
		{
			estimator = new CompressedEstimator(data, tests, indEvents, proj);
		}
		else if(historyType.equals("Suffix"))
		{
			estimator = new CompressedSuffixHistoryEstimator(data, tests, indEvents, proj, maxHistoryLength);
		}
		else
		{
			throw new PSRBuildException("Unknown history Type");
		}
		estimator.estimateObservableMatrices(runs);
		//System.out.println("Finished obtaining empirical estimates");

		phEst = estimator.getPhEst();
		xth = estimator.getPthEst();
		xthos = estimator.getPtaohsEst();
	}

	/**
	 * Performs estimation of parameters in original space. 
	 * 
	 * @param runs Number of runs in estimation.
	 * @param historypsrType psrType of histories 
	 */
	private void estimateInOriginalSpace(int runs)
	{
		Matrix pthEst;
		HashMap<ActionObservation, Matrix> ptaohsEst;

		//getting estimates
		Estimator estimator = null;
		if(historyType.equals("Standard"))
		{
			estimator = new Estimator(data, tests, indEvents);
		}
		else if(historyType.equals("Suffix"))
		{
			estimator = new SuffixHistoryEstimator(data, tests, indEvents, maxHistoryLength);
		}
		else
		{
			throw new PSRBuildException("Unknown history type");
		}

		estimator.estimateObservableMatrices(runs);
		//System.out.println("Finished obtaining empirical estimates");
		phEst = estimator.getPhEst();
		xth = estimator.getPthEst();
		xthos = estimator.getPtaohsEst();
	}

	/**
	 * Performs SVD on learned parameters. 
	 * 
	 * @param svdDim Number of singular vectors to keep. 
	 */
	private void performSVD(int svdDim)
	{
		Matrix uT;
		SVD svd = new SVD(xth);
		uT = svd.getU(svdDim).transpose();

		xth = uT.times(xth);
		for(ActionObservation o : xthos.keySet())
		{
			xthos.put(o, uT.times(xthos.get(o)));
		}
	}

	/**
	 * Helper method for learning in compressed space
	 * 
	 * @param runs 
	 * @param randomProjectionDim
	 * @param svdDim
	 */
	private void learnInCompressedSpace(int runs, int randomProjectionDim, int svdDim)
	{

		HashMap<ActionObservation, Matrix> targets = new HashMap<ActionObservation, Matrix>(); 
		HashMap<ActionObservation, Mao> temps = new HashMap<ActionObservation, Mao>();
		Matrix target = null;
		Minf temp;

		for(int i = 0; i < 1; i++)
		{
			estimateInCompressedSpace(runs, randomProjectionDim);
			if(psrType.equals("Combined")) performSVD(svdDim);
			if(i == 0)
			{
				learner = new Learner(xthos, xth, phEst);
				maos = learner.learnMaos();
				mInf = learner.learnMinf();
			}
			else
			{	
				learner = new Learner(targets, xth, target);
				temps = learner.learnMaos();
				temp = learner.learnMinf();

				for(ActionObservation actob : data.getValidActionObservationSet())
				{
					maos.put(actob, new Mao(temps.get(actob).getMatrix().plus(maos.get(actob).getMatrix())));
				}
				try
				{
					mInf = new Minf(mInf.getVector().plus(temp.getVector()));
				}
				catch(PSRParameterException ex)
				{
					ex.printStackTrace();
				}
			}
			/*for(ActionObservation actob : data.getValidActionObservationSet())
			{
				targets.put(actob, xthos.get(actob).minus(maos.get(actob).getMatrix().times(xth)));
			}
			target = phEst.minus((mInf.getVector().transpose().times(xth)).transpose());*/
		}
	}

	/* (non-Javadoc)
	 * @see cpsr.model.IPSR#isBuilt()
	 */
	@Override
	public boolean isBuilt()
	{
		return built;
	}

	/* (non-Javadoc)
	 * @see cpsr.model.IPSR#getDataSet()
	 */
	@Override
	public DataSet getDataSet()
	{
		return data;
	}

	/* (non-Javadoc)
	 * @see cpsr.model.IPSR#update(cpsr.environment.components.ActionObservation)
	 */
	@Override
	public void update(ActionObservation ao)
	{
		Mao tempMao = maos.get(ao);
		Matrix numerator, denominator;

		try
		{
			numerator = tempMao.getMatrix().times(pv.getVector());
		}
		catch(NullPointerException ex)
		{
			//System.err.print("Unknown observation: no update performed");
			return;
		}
		denominator = mInf.getVector().transpose().times(numerator);

		try 
		{
			if(!(denominator.get(0, 0) == 0.0)) pv = new PredictionVector(numerator.times((1.0/denominator.get(0,0))));
		} catch (PVException e) 
		{	
			e.printStackTrace();
			System.exit(0);
		}
	}

	/* (non-Javadoc)
	 * @see cpsr.model.IPSR#resetToStartState()
	 */
	@Override
	public void resetToStartState()
	{
		try
		{
			pv = new PredictionVector(initialPv.getVector().copy());
		}
		catch(PVException ex)
		{
			ex.printStackTrace();
		}
	}
	
	/* (non-Javadoc)
	 * @see cpsr.model.IPSR#getActionSet()
	 */
	@Override
	public HashSet<Action> getActionSet()
	{
		return this.data.getActionSet();
	}

	/**
	 * Returns deep copy of prediction vector.
	 * 
	 * @return Deep copy of prediction vector.
	 */
	public PredictionVector getPredictionVector()
	{
		try
		{
			return new PredictionVector(pv.getVector());
		}
		catch(PVException ex)
		{
			ex.printStackTrace();
		}
		return null;
	}

	/**
	 * Returns reference to Minf parameter.
	 * 
	 * @return Reference to Minf parameter.
	 */
	public Minf getMinf()
	{
		return mInf;
	}

	/**
	 * Returns reference to specified Mao parameter matrix. 
	 * 
	 * @param actob The action observation pair used to specify the Mao.
	 * @return The specified Mao parameter matrix. 
	 * @throws PSRRuntimeException
	 */
	public Mao getMao(ActionObservation actob) throws PSRRuntimeException
	{
		Mao mao = maos.get(actob);

		if(mao == null)
		{
			throw new PSRRuntimeException("There is no parameter associated with this action-observation pair");
		}
		else
		{
			return mao;
		}

	}

	/**
	 * Returns hash map of Mao parameters. 
	 * 
	 * @return Hash map of Mao parameters. 
	 */
	public HashMap<ActionObservation, Mao> getMaos()
	{
		return maos;
	}

}








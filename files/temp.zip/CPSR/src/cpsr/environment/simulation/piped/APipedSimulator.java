package cpsr.environment.simulation.piped;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import cpsr.environment.DataSet;
import cpsr.environment.components.Action;
import cpsr.environment.components.ActionObservation;
import cpsr.environment.components.Observation;
import cpsr.environment.exceptions.EnvironmentException;
import cpsr.environment.simulation.ISimulator;
import cpsr.planning.APSRPlanner;

/**
 * Parent class used for performing simulation.
 * 
 * @author William Hamilton
 * @deprecated
 */
public abstract class APipedSimulator implements ISimulator {

	protected ArrayList<ArrayList<Action>> acts;
	protected ArrayList<ArrayList<Observation>> obs;
	protected ArrayList<ArrayList<Double>> rewards;
	protected SimPipe simPipe;
	
	/**
	 * Default constructor for inheritence
	 */
	public APipedSimulator()
	{
		super();
	}
	
	/**
	 * Constructs a piped simulator with a SimPipe.
	 * 
	 * @param simPipe
	 */
	public APipedSimulator(SimPipe simPipe)
	{
		this.simPipe = simPipe;
	}
	
	public APipedSimulator(int port) throws IOException
	{
		this.simPipe = new SimPipe(port);
	}
	
	@Override
	public DataSet runSimulator(int runs)
	{
		return simulateRuns(runs, true, null);
	}
	
	@Override
	public DataSet runSimulator(int runs, APSRPlanner planner)
	{
		return simulateRuns(runs, false, planner);
	}
		
	/**
	 * Helper method simulates runs using random actions or
	 * a policy
	 * 
	 * @param runs Number of runs.
	 * @param random Boolean switch.
	 * @param planner The planner defining the policy.
	 * @return A dataset produced by the simulation.
	 */
	private DataSet simulateRuns(int runs, boolean random, APSRPlanner planner) 
	{
		checkSimPipe();
		ArrayList<Action> actionList = null;
		Action act = null;
		DataSet dataPointer = null;
		actionList = getActionList();
		if(random)
		{
			dataPointer = new DataSet();
		}
		else
		{
			dataPointer = planner.getCurrentData();
		}
		initializeListsForRuns();
		
		int runCount = 0;
		while(runCount < runs)
		{
			if(random)
			{
				act = getRandomAction(actionList);
			}
			else
			{
				act = planner.getAction();
				if(act == null)
				{
					System.err.println("Null action");
					act = getRandomAction(actionList);
				}
				act.setData(dataPointer);
			}
			
			double[] stepInfo = simPipe.takeAction(act);
			Observation ob = convertIntToObservation((int)stepInfo[1]);
			ob.setData(dataPointer);
			addStepData(act, ob, stepInfo[0], runCount);
			if(!random) planner.update(new ActionObservation(act, ob));
		
			if(simPipe.checkIfLastTerminal())
			{
				runCount++;
				if(runCount < runs) setUpListsForNewRun();
				if(!random) planner.resetToStartState();
			}
		}
		simPipe.terminate();
		DataSet data =  new DataSet(acts, obs, rewards);
		if(random) dataPointer = data;
		return data;
	}

	/**
	 * Initializes data lists for runs
	 */
	protected void initializeListsForRuns()
	{
		acts =  new ArrayList<ArrayList<Action>>();
		obs = new ArrayList<ArrayList<Observation>>();
		rewards = new ArrayList<ArrayList<Double>>();
		acts.add(new ArrayList<Action>());
		obs.add(new ArrayList<Observation>());
		rewards.add(new ArrayList<Double>());
	}
	
	/**
	 * Sets up data lists for new run.
	 */
	protected void setUpListsForNewRun()
	{
		acts.add(new ArrayList<Action>());
		obs.add(new ArrayList<Observation>());
		rewards.add(new ArrayList<Double>());
	}
	
	/**
	 * Returns a random action.
	 * 
	 * @param actionList List of actions.
	 * @return A random valid action.
	 */
	protected Action getRandomAction(ArrayList<Action> actionList)
	{
		Random rando = new Random();
		return actionList.get(rando.nextInt(actionList.size()));
	}
	
	/**
	 * Ensures that the SimPipe has been initialized.
	 */
	protected void checkSimPipe()
	{
		if(simPipe == null)
		{
			throw new EnvironmentException("All piped simulators must set a SimPipe" +
					"during construction");
		}
	}
	
	/**
	 * Converts an integer to an observation.
	 * 
	 * @return An observation
	 */
	protected Observation convertIntToObservation(int id)
	{
		return new Observation(id);
	}
	
	/**
	 * Adds the data to lists for one step. 
	 * 
	 * @param act
	 * @param ob
	 * @param reward
	 * @param runCount
	 */
	protected void addStepData(Action act, Observation ob, double reward, int runCount)
	{
		acts.get(runCount).add(act);
		obs.get(runCount).add(ob);
		rewards.get(runCount).add(reward);
	}
	
	/**
	 * Returns the list of actions applicable in an environment.
	 * 
	 * @return Action list.
	 */
	protected abstract ArrayList<Action> getActionList();
	
}

/*
 *   Copyright 2012 William Hamilton
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 */

package cpsr.environment.simulation.piped;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import cpsr.environment.DataSet;
import cpsr.environment.components.Action;
import cpsr.planning.RandomPlanner;

/**
 * Class for simulating with grid world through
 * a pipe.
 * 
 * @author William Hamilton
 * @deprecated
 */
public class PipedGridWorldSimulator extends APipedSimulator 
{

	public PipedGridWorldSimulator(int port) throws IOException
	{
		this.simPipe = new SimPipe(port);
	}
	
	@Override
	protected ArrayList<Action> getActionList() 
	{
		ArrayList<Action> actionList = new ArrayList<Action>();
		
		for(int i = 1; i <= 4; i++)
		{
			actionList.add(new Action(i));
		}
		return actionList;
	}
	
	public static void main(String[] args)
	{
		try
		{
			PipedGridWorldSimulator gridSim = new PipedGridWorldSimulator(7708);
			DataSet data = gridSim.runSimulator(10000);
			
		/*	TestSetGenerator testGen = new TestSetGenerator(data);
			IndicativeEventSetGenerator indGen = new IndicativeEventSetGenerator(data);
			
			PSR psr = new PSR(data, testGen.generateTestSet(4), indGen.generateSuffixHistoryIndicativeEvents(4), "CPSR", "Suffix", 4);
			
			psr.buildPSR(1000, 30, 0);
			SingleEnsembleERTQPlanner qPlanner = new SingleEnsembleERTQPlanner(psr);
			
			qPlanner.learnPolicy(data, 50, 2, 3, 5, 200);
			
			DataSet results = gridSim.runSimulator(100, qPlanner);*/
			
			try
			{
				ObjectOutputStream obOut = new ObjectOutputStream(new FileOutputStream("/home/2011/whamil3/rl_research/pacman/runs/10r-matlabsim"));
				obOut.writeObject(data);
				obOut.close();
			}
			catch(IOException ex)
			{
				ex.printStackTrace();
			}
		}
		catch(IOException ex)
		{
			ex.printStackTrace();
		}
	}
	
	public RandomPlanner getRandomPlanner(int pSeed)
	{
		return new RandomPlanner(pSeed, getActionList());
	}

	@Override
	public void setMaxRunLength(int pMaxRunLength) {
		// TODO Auto-generated method stub
		
	}
}

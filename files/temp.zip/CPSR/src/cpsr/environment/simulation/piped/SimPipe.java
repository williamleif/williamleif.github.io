/*
 *   Copyright 2012 William Hamilton
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 */
package cpsr.environment.simulation.piped;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

import cpsr.environment.components.Action;

/**
 * Class for doing simulations
 * @author whamil3
 * @deprecated
 *
 */
public class SimPipe  {

	/** Input object */
	protected BufferedReader in;
	/** Output object */
	protected PrintStream out;
	protected boolean hasObserved, checkedTerminal;


	/** Uses named pipes */
	public SimPipe(int port)
	{
		try
		{
			ServerSocket server = new ServerSocket(port);
			Socket simSocket = server.accept();
			out = new PrintStream(simSocket.getOutputStream(), true);
			in = new BufferedReader(new InputStreamReader(simSocket.getInputStream()));
		}
		catch(IOException ex)
		{
			ex.printStackTrace();
		}
		hasObserved = true;
		checkedTerminal = true;
		
	}


	/** Closes the I/O channel.
	 * 
	 */
	public void close() {
		try 
		{
			in.close();
			out.close();
		}
		catch (IOException e) {
			// Not sure what to do if we can't close streams...
		}
	}

	/**
	 * Takes an action
	 * 
	 * @param act
	 * @return
	 */
	public double[] takeAction(Action act)
	{
		act(act.getID());

		return observe();
	}

	/**
	 * Checks if last state terminal in run
	 * 
	 * @return
	 */
	public boolean checkIfLastTerminal()
	{
		String line = null;
		checkedTerminal = true;
		try
		{
			line = in.readLine();
		}catch(IOException ex)
		{
			ex.printStackTrace();
		}

		if(line == null)
		{
			return false;
		}
		else
		{
			return line.equals("end");
		}

	}

	/** A blocking method which will get the next time step from simulator.
	 *
	 */
	private double[] observe() 
	{
		// Ensure that observe() is not called twice, as it will otherwise block
		//  as both ALE and the agent wait for data.
		if (hasObserved) 
		{
			throw new RuntimeException("observe() called without subsequent act().");
		}
		else
			hasObserved = true;

		String line = null;

		// First read in a new line from ALE
		try 
		{
			line = in.readLine();
		}
		catch (IOException e) {
			e.printStackTrace();
		}

		String[] lineData = line.split(",");
		try
		{
			double[] data =  new double[2];
			data[0] = Double.parseDouble(lineData[0]);
			data[1] = Double.parseDouble(lineData[1]);
			return data; 
		}
		catch(NumberFormatException ex)
		{
			System.err.println("Simulator must send observation and reward as comma seperated values" +
			"in that order (i.e. <integer,double>.");
			System.exit(0);
			return null;
		}

	}

	/**
	 * terminates a session.
	 */
	public void terminate()
	{
		sendAction(-2);
		close();
	}

	/** After a call to observe(), send back the necessary action.
	 * 
	 * @param act
	 * @return
	 */
	private boolean act(int act) 
	{
		// Ensure that we called observe() last
		if (!hasObserved) 
		{
			throw new RuntimeException("act() called before observe().");
		}
		else
			hasObserved = false;

		if(!checkedTerminal) throw new RuntimeException("Must check if last state terminal" +
		" before taking action");

		sendAction(act);

		return false;
	}

	/** Helper function to send out an action*/
	public void sendAction(int act) 
	{
		out.printf("%d\n", act);
		out.flush();
	}

	/**
	 * Pauses for specified wait time.
	 * 
	 * @param waitTime
	 */
	protected void pause(long waitTime) {
		try {
			Thread.sleep(waitTime);
		}
		catch (Exception e) {
		}
	}


}



/*
 *   Copyright 2013 William Hamilton
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 */
package cpsr.environment.simulation.domains;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;

import cpsr.environment.DataSet;
import cpsr.environment.components.Action;
import cpsr.environment.components.ActionObservation;
import cpsr.environment.components.Observation;
import cpsr.environment.exceptions.EnvironmentException;
import cpsr.environment.obsonly.ObsOnlyDataSet;
import cpsr.environment.simulation.ISimulator;
import cpsr.environment.utils.IndicativeEventSetGenerator;
import cpsr.environment.utils.TestSetGenerator;
import cpsr.model.PSR;
import cpsr.model.averaging.BayesAveragedPSR;
import cpsr.planning.APSRPlanner;
import cpsr.planning.RandomPlanner;
import cpsr.planning.ertapprox.averaged.BayesAveragedActEnsQPlanner;
import cpsr.stats.Basic;

public class Follow implements ISimulator 
{

	private int[] aPersPos, aAgentPos;
	private int aPersonID, aCurrDist;
	private double aTerminalReward;
	private Random aRando;
	private ArrayList<Integer> aPersMoveProbs;
	private int aMaxRunLength = Integer.MAX_VALUE;

	public Follow(int pSeed)
	{
		aRando = new Random(pSeed);
		aTerminalReward = -20.0;

		initRun();
	}

	public ObsOnlyDataSet runSimulatorObsOnly(int runs, boolean greedyFollow, int runLength)
	{
		int lCurrRun, lLastSeenPersonPos;
		double lCurrReward;
		Action lCurrAction;
		Observation lCurrObs;

		RandomPlanner lActGen = new RandomPlanner(aRando.nextInt(), 0, 5);

		ArrayList<ArrayList<Observation>> lObs = new ArrayList<ArrayList<Observation>>();

		for(lCurrRun = 0; lCurrRun < runs; lCurrRun++)
		{
			lCurrReward = 0.0;
			ArrayList<Observation> lRunObs = new ArrayList<Observation>();
			lLastSeenPersonPos = 0;
			int itCount = 0;
			while(lCurrReward != aTerminalReward && itCount < runLength)
			{
				if(greedyFollow)
				{
					lCurrAction = new Action(lLastSeenPersonPos);
				}
				else
				{
					lCurrAction = lActGen.getAction();
				}

				calcCurrDist();
				lCurrReward = getCurrReward();
				lCurrObs = getCurrObservation();
				lRunObs.add(lCurrObs);

				movePerson();
				moveAgent(lCurrAction.getID());

				if(lCurrObs.getID()!=5) lLastSeenPersonPos = lCurrObs.getID();

				itCount++;
			}
			initRun();
			lObs.add(lRunObs);
		}

		HashSet<Observation> obsSet = new HashSet<Observation>();
		for(int i = 0; i < 6; i++) obsSet.add(new Observation(i));

		return new ObsOnlyDataSet(lObs, obsSet, 5);
	}

	@Override
	public DataSet runSimulator(int runs) 
	{
		int lCurrRun;
		double lCurrReward;
		Observation lCurrObs;
		Action lCurrAction;

		RandomPlanner lActGen = new RandomPlanner(aRando.nextInt(), 0, 5);

		ArrayList<ArrayList<Action>> lActs = new ArrayList<ArrayList<Action>>();
		ArrayList<ArrayList<Observation>> lObs = new ArrayList<ArrayList<Observation>>();
		ArrayList<ArrayList<Double>> lRewards = new ArrayList<ArrayList<Double>>();


		for(lCurrRun = 0; lCurrRun < runs; lCurrRun++)
		{
			lCurrReward = 0.0;
			ArrayList<Action> lRunActs = new ArrayList<Action>();
			ArrayList<Observation> lRunObs = new ArrayList<Observation>();
			ArrayList<Double> lRunRewards = new ArrayList<Double>();
			
			
			int lCounter = 0;
			while(lCurrReward != aTerminalReward && lCounter < aMaxRunLength)
			{
				lCurrAction = lActGen.getAction();
		
				movePerson();
				moveAgent(lCurrAction.getID());
				calcCurrDist();
				
				lCurrObs = getCurrObservation();
				lCurrObs.setMaxID(5);
				lCurrAction.setMaxID(4);
				lRunObs.add(lCurrObs);
				lRunActs.add(lCurrAction);
				lCurrReward = getCurrReward();
				lRunRewards.add(lCurrReward);
				
				lCounter++;
			}
			lActs.add(lRunActs);
			lObs.add(lRunObs);
			lRewards.add(lRunRewards);

			initRun();
		}

		return new DataSet(lActs, lObs, lRewards);

	}

	@Override
	public DataSet runSimulator(int runs, APSRPlanner pPlanner) {
		int lCurrRun;
		double lCurrReward;
		Action lCurrAction;
		Observation lCurrObs;

		ArrayList<ArrayList<Action>> lActs = new ArrayList<ArrayList<Action>>();
		ArrayList<ArrayList<Observation>> lObs = new ArrayList<ArrayList<Observation>>();
		ArrayList<ArrayList<Double>> lRewards = new ArrayList<ArrayList<Double>>();


		for(lCurrRun = 0; lCurrRun < runs; lCurrRun++)
		{
			lCurrReward = 0.0;
			ArrayList<Action> lRunActs = new ArrayList<Action>();
			ArrayList<Observation> lRunObs = new ArrayList<Observation>();
			ArrayList<Double> lRunRewards = new ArrayList<Double>();
			pPlanner.resetToStartState();
			
			int lCounter = 0;
			while(lCurrReward != aTerminalReward && lCounter < aMaxRunLength)
			{

				lCurrAction = pPlanner.getAction();
				
				moveAgent(lCurrAction.getID());
				movePerson();
				calcCurrDist();
				
				lCurrObs = getCurrObservation();
				lCurrObs.setMaxID(5);
				lCurrAction.setMaxID(4);
				lRunObs.add(lCurrObs);
				lRunActs.add(lCurrAction);
				lCurrReward = getCurrReward();
				lRunRewards.add(lCurrReward);
				
				pPlanner.update(new ActionObservation(lCurrAction,lCurrObs));
				lCounter++;
			}
			lActs.add(lRunActs);
			lObs.add(lRunObs);
			lRewards.add(lRunRewards);
			initRun();
		}

		return new DataSet(lActs, lObs, lRewards);
	
	}


	/**
	 * Initializes a run/episode.
	 * Resets agent and person to same position.
	 * Randomly chooses new person (among the two possibilities).
	 */
	private void initRun()
	{
		aPersMoveProbs = new ArrayList<Integer>();
		aPersonID = aRando.nextInt(1)+1;
		aCurrDist = 0;

		aAgentPos = new int[2];
		aPersPos = new int[2];
		aAgentPos[0] = 0;
		aPersPos[0] = 0;
		aAgentPos[1] = 0;
		aAgentPos[1] = 0;

		if(aPersonID == 1)
		{
			//no move prob
			for(int i = 0; i < 30; i++)aPersMoveProbs.add(0);
			//north move prob
			for(int i = 0; i < 40; i++)aPersMoveProbs.add(1);
			//east move prob
			for(int i = 0; i < 20; i++)aPersMoveProbs.add(2);
			//south move pob
			for(int i = 0; i < 5; i++)aPersMoveProbs.add(3);
			//west move prob
			for(int i = 0; i < 5; i++)aPersMoveProbs.add(4);
		}
		else
		{
			//no move prob
			for(int i = 0; i < 10; i++)aPersMoveProbs.add(0);
			//north move prob
			for(int i = 0; i < 5; i++)aPersMoveProbs.add(1);
			//east move prob
			for(int i = 0; i < 80; i++)aPersMoveProbs.add(2);
			//south move pob
			for(int i = 0; i < 3; i++)aPersMoveProbs.add(3);
			//west move prob
			for(int i = 0; i < 2; i++)aPersMoveProbs.add(4);
		}
	}

	/**
	 * Moves the person random according to identity.
	 */
	private void movePerson()
	{
		makeMove(aPersPos, aPersMoveProbs.get(aRando.nextInt(100)));
		//makeMove(aPersPos, aRando.nextInt(5));
	}

	/**
	 * Moves the agent according to specified action.
	 * @param pAction The action to take.
	 */
	private void moveAgent(int pAction)
	{
		if(pAction < 0 || pAction > 4)
		{
			throw new EnvironmentException("Illegal action ID for follow. Must be in range [0,4]");
		}
		makeMove(aAgentPos, pAction);
	}

	/**
	 * Alters position array according to action.
	 * @param pPos The position array.
	 * @param pAction The action to take.
	 */
	private void makeMove(int[] pPos, int pAction)
	{
		switch(pAction)
		{
		case 1:
			pPos[1]++;
			break;
		case 2:
			pPos[0]++;
			break;
		case 3:
			pPos[1]--;
			break;
		case 4:
			pPos[0]--;
			break;
		}
	}

	/**
	 * Recomputes current distance from agent to person.
	 */
	private void calcCurrDist()
	{
		aCurrDist = Math.abs(aPersPos[0]-aAgentPos[0])+Math.abs(aPersPos[1]-aAgentPos[1]);
	}

	/**
	 * @return the current reward according to distance.
	 */
	private double getCurrReward()
	{

		if(aCurrDist == 0)
		{
			return 1.0;
		}
		else if(aCurrDist == 1)
		{
			return 0.0;
		}
		else if(aCurrDist  == 2)
		{
			return -1.0;
		}
		else
		{
			return -20.0;
		}
	}


	/**
	 * @return The current observation.
	 */
	private Observation getCurrObservation()
	{
		Observation lCurrObs;

		if(aRando.nextDouble() < 0.8 && aCurrDist <= 1)
		{
			if(aCurrDist == 0)
			{
				lCurrObs = new Observation(0);
			}
			else if(aAgentPos[0] == aPersPos[0])
			{
				if(aAgentPos[1] - aPersPos[1] < 0)
				{
					lCurrObs = new Observation(1);
				}
				else
				{
					lCurrObs = new Observation(3);
				}
			}
			else
			{
				if(aAgentPos[0] - aPersPos[0] < 0)
				{
					lCurrObs = new Observation(4);
				}
				else
				{
					lCurrObs = new Observation(2);
				}
			}
		}
		else
		{
			lCurrObs = new Observation(5);
		}

		return lCurrObs;

	}
	
	@Override
	public RandomPlanner getRandomPlanner(int pSeed)
	{
		return new RandomPlanner(pSeed, 0, 5);
	}

	@Override
	public void setMaxRunLength(int pMaxRunLength) 
	{
		aMaxRunLength = pMaxRunLength;
		
	}


}

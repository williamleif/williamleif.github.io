/*
 *   Copyright 2013 William Hamilton
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 */
package cpsr.environment.simulation;

import java.util.ArrayList;

import pomdp.environments.POMDP;
import cpsr.environment.DataSet;
import cpsr.environment.components.Action;
import cpsr.environment.components.ActionObservation;
import cpsr.environment.components.Observation;
import cpsr.planning.APSRPlanner;
import cpsr.planning.IPlanner;
import cpsr.planning.RandomPlanner;

/**
 * Wrapper that allows Cassandra style .POMDP file defined domains to be used for simulation,
 * learning and planning.
 * The code uses Guy Shani's POMDP package to parse the .POMDP files.
 * 
 * @author William Hamilton
 */
public class CassandraPOMDPSim implements ISimulator {

	private POMDP aPOMDPSim;
	private int aSeed;
	private int aMaxRunLength = Integer.MAX_VALUE;
	
	/**
	 * Constructs a Cassandra .POMDP simulator from specified file.
	 * 
	 * @param pFileName Path to .POMDP file.
	 * @param pSeed Random seed to use.
	 */
	public CassandraPOMDPSim(String pFileName, int pSeed)
	{
		aPOMDPSim = new POMDP();
		try
		{
			aPOMDPSim.load(pFileName);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		aSeed = pSeed;
	}
	
	@Override
	public DataSet runSimulator(int runs) {
		int lCurrRun;
		double lCurrReward;
		Action lCurrAction;
		Observation lCurrObs;
		IPlanner lActGen = new RandomPlanner(aSeed, 0,aPOMDPSim.getActionCount());
		
		int lCurrState; 
		
		ArrayList<ArrayList<Action>> lActs = new ArrayList<ArrayList<Action>>();
		ArrayList<ArrayList<Observation>> lObs = new ArrayList<ArrayList<Observation>>();
		ArrayList<ArrayList<Double>> lRewards = new ArrayList<ArrayList<Double>>();


		for(lCurrRun = 0; lCurrRun < runs; lCurrRun++)
		{
			lCurrState = aPOMDPSim.chooseStartState();
			
			lCurrReward = 0.0;
			ArrayList<Action> lRunActs = new ArrayList<Action>();
			ArrayList<Observation> lRunObs = new ArrayList<Observation>();
			ArrayList<Double> lRunRewards = new ArrayList<Double>();
			
			int lCounter = 0;
			while(!aPOMDPSim.isTerminalState(lCurrState) && lCounter < aMaxRunLength)
			{

				lCurrAction = lActGen.getAction();
				lCurrReward = aPOMDPSim.R(lCurrState, lCurrAction.getID());
				lCurrObs = new Observation(aPOMDPSim.observe(lCurrAction.getID(), lCurrState));
				lCurrObs.setMaxID(aPOMDPSim.getActionCount());
				lCurrAction.setMaxID(aPOMDPSim.getObservationCount());
				lRunObs.add(lCurrObs);
				lRunActs.add(lCurrAction);
				lRunRewards.add(lCurrReward);
				

				lCurrState = aPOMDPSim.execute(lCurrAction.getID(), lCurrState);
				lCounter++;
			}
			lActs.add(lRunActs);
			lObs.add(lRunObs);
			lRewards.add(lRunRewards);
		}

		return new DataSet(lActs, lObs, lRewards);
		
	}

	@Override
	public DataSet runSimulator(int runs, APSRPlanner planner) {
		int lCurrRun;
		double lCurrReward;
		Action lCurrAction;
		Observation lCurrObs;
		
		int lCurrState; 
		
		ArrayList<ArrayList<Action>> lActs = new ArrayList<ArrayList<Action>>();
		ArrayList<ArrayList<Observation>> lObs = new ArrayList<ArrayList<Observation>>();
		ArrayList<ArrayList<Double>> lRewards = new ArrayList<ArrayList<Double>>();


		for(lCurrRun = 0; lCurrRun < runs; lCurrRun++)
		{
			lCurrState = aPOMDPSim.chooseStartState();
			
			lCurrReward = 0.0;
			ArrayList<Action> lRunActs = new ArrayList<Action>();
			ArrayList<Observation> lRunObs = new ArrayList<Observation>();
			ArrayList<Double> lRunRewards = new ArrayList<Double>();
			
			int lCounter = 0;
			while(!aPOMDPSim.isTerminalState(lCurrState) && lCounter < aMaxRunLength)
			{

				lCurrAction = planner.getAction();
				lCurrReward = aPOMDPSim.R(lCurrState, lCurrAction.getID());
				lCurrObs = new Observation(aPOMDPSim.observe(lCurrAction.getID(), lCurrState));
				lCurrObs.setMaxID(aPOMDPSim.getActionCount());
				lCurrAction.setMaxID(aPOMDPSim.getObservationCount());
				lRunObs.add(lCurrObs);
				lRunActs.add(lCurrAction);
				lRunRewards.add(lCurrReward);
				
				
				planner.update(new ActionObservation(lCurrAction, lCurrObs));

				lCurrState = aPOMDPSim.execute(lCurrAction.getID(), lCurrState);
				lCounter++;
			}
			lActs.add(lRunActs);
			lObs.add(lRunObs);
			lRewards.add(lRunRewards);
		}

		return new DataSet(lActs, lObs, lRewards);
	}
	
	@Override
	public RandomPlanner getRandomPlanner(int pSeed)
	{
		return new RandomPlanner(pSeed, 0,aPOMDPSim.getActionCount());
	}

	@Override
	public void setMaxRunLength(int pMaxRunLength)
	{
		aMaxRunLength = pMaxRunLength;
		
	}
	
	

}

/*
 *   Copyright 2012 William Hamilton
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 */

package cpsr.environment;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;

import cpsr.environment.components.Action;
import cpsr.environment.components.ActionObservation;
import cpsr.environment.components.Observation;
import cpsr.environment.components.ResetActionObservation;
import cpsr.environment.exceptions.EnvironmentException;

/**
 * Class encapsulates a data set generated from an environment
 * simulator or taken from file.
 * Contains all information necessary to build PSR representation
 * of a domain.
 * 
 * @author William Hamilton
 *
 */
@SuppressWarnings("serial")
public class DataSet implements Serializable{

	/**
	 * @serialField
	 */
	protected ArrayList<ArrayList<ActionObservation>> data;

	/**
	 * @serialField
	 */
	protected ArrayList<ArrayList<Double>> rewards;

	/**
	 * @serialField
	 */
	protected HashSet<Action> validActs;

	/**
	 * @serialField
	 */
	protected HashSet<Observation> validObs;

	/**
	 * @serialField
	 */
	protected HashSet<ActionObservation> validActObs;

	/**
	 * @serialField
	 */
	protected int maxActID, maxObsID;

	protected int runCounter, stepCounter;

	/**
	 * Explicit default constructor for inheritance.
	 */
	public DataSet()
	{
		super();
	}

	/**
	 * Constructs DataSet object from ArrayList of training runs, where
	 * each training run is a ArrayList of action observations. 
	 * @param data The list of action and observations
	 * @param rewards The list of rewards associated with the action observation data.
	 * @param acts Set of all valid actions in the domain associated with data set.
	 * @param obs Set of all valid observations in the domain associated with data set.
	 * @param validActObs Set of all valid action observation pairs in the domain associated with data set.
	 * @param maxActID maximum ID of observation in the domain associated with data set.
	 * @param maxObsID maximum ID of action in the domain associated with data set.
	 * (Note: must be one to one correspondence between these two objects).
	 */
	public DataSet(ArrayList<ArrayList<Action>> acts, ArrayList<ArrayList<Observation>> obs,
			ArrayList<ArrayList<Double>> rewards)
	{
		this.maxActID = Integer.MIN_VALUE;
		this.maxObsID = Integer.MIN_VALUE;
		this.data = new ArrayList<ArrayList<ActionObservation>>();
		this.validActObs = new HashSet<ActionObservation>();
		this.validActs = new HashSet<Action>();
		this.validObs = new HashSet<Observation>();

		//sanity check
		if(acts.size() != rewards.size() || acts.size() != obs.size() || 
				rewards.size() != obs.size())
		{
			throw new EnvironmentException("There must be an equal number of runs in " +
			"action, observation, and reward lists");
		}
		int i = 0;
		for(ArrayList<Action> run : acts)
		{
			if(run.size() != rewards.get(i).size() || run.size() != obs.get(i).size() ||
					rewards.get(i).size() != obs.get(i).size())
			{
				throw new EnvironmentException("All runs in action, observation, and reward " +
				"lists must be the same length");
			}
			int j = 0;
			data.add(new ArrayList<ActionObservation>());
			for(Action act : run)
			{
				act.setData(this);
				obs.get(i).get(j).setData(this);
				if(act.getID() > maxActID) maxActID = act.getID();
				if(obs.get(i).get(j).getID() > maxObsID) maxObsID = obs.get(i).get(j).getID();

				ActionObservation actob = new ActionObservation(act, obs.get(i).get(j));
				data.get(i).add(actob);
				validActObs.add(actob);
				validActs.add(act);
				validObs.add(obs.get(i).get(j));
				j++;
			}
			data.get(i).add(new ResetActionObservation(this));
			i++;
		}
		this.rewards = rewards;
		runCounter = 0;
		stepCounter = 0;
	}

	/**
	 * Constructs DataSet object from ArrayList of training runs, where
	 * each training run is a ArrayList of action observations. 
	 * @param data The list of action and observations
	 * @param rewards The list of rewards associated with the action observation data.
	 * @param acts Set of all valid actions in the domain associated with data set.
	 * @param obs Set of all valid observations in the domain associated with data set.
	 * @param validActObs Set of all valid action observation pairs in the domain associated with data set.
	 * @param maxActID maximum ID of observation in the domain associated with data set.
	 * @param maxObsID maximum ID of action in the domain associated with data set.
	 * (Note: must be one to one correspondence between these two objects).
	 */
	public DataSet(ArrayList<ArrayList<ActionObservation>> actobs, 
			ArrayList<ArrayList<Double>> rewards)
	{
		this.maxActID = Integer.MIN_VALUE;
		this.maxObsID = Integer.MIN_VALUE;
		this.data = new ArrayList<ArrayList<ActionObservation>>();
		this.validActObs = new HashSet<ActionObservation>();
		this.validActs = new HashSet<Action>();
		this.validObs = new HashSet<Observation>();

		int i = 0;
		for(ArrayList<ActionObservation> run : actobs)
		{
			int j = 0;
			data.add(new ArrayList<ActionObservation>());
			for(ActionObservation actob : run)
			{
				if(j != actobs.size()-1)
				{
					actob.getAction().setData(this);
					actob.getObservation().setData(this);
					if(actob.getAction().getID() > maxActID) maxActID = actob.getAction().getID();
					if(actob.getObservation().getID() > maxObsID) maxObsID = actob.getObservation().getID();

					data.get(i).add(actob);
					validActObs.add(actob);
					validActs.add(actob.getAction());
					validObs.add(actob.getObservation());
					j++;
				}
			}
			data.get(i).add(new ResetActionObservation(this));
			i++;
		}
		this.rewards = rewards;
		runCounter = 0;
		stepCounter = 0;
	}

	/**
	 * Returns next action-observation pair
	 * @return Next action-observation pair
	 */
	public ActionObservation getNextActionObservation()
	{
		ActionObservation actob =  data.get(runCounter).get(stepCounter);
		stepCounter++;
		if(stepCounter == data.get(runCounter).size())
		{
			stepCounter = 0;
			runCounter = (runCounter+1)%data.size();
		}
		return actob;
	}

	/**
	 * Returns next action-observation pair
	 * @return Next action-observation pair
	 */
	public ActionObservation getNextActionObservationForPlanning()
	{
		ActionObservation actob =  data.get(runCounter).get(stepCounter);
		stepCounter++;
		if(stepCounter == data.get(runCounter).size()-1)
		{
			stepCounter = 0;
			runCounter = (runCounter+1)%data.size();
		}
		return actob;
	}
	
	public void resetData()
	{
		stepCounter = 0;
		runCounter = 0;
	}

	/**
	 * Returns reward associated with current (i.e. last returned
	 * action observation pair).
	 * 
	 * @return Reward.
	 */
	public double getReward()
	{
		if(stepCounter != 0)
		{
			return rewards.get(runCounter).get(stepCounter-1);
		}
		else
		{
			return rewards.get(runCounter-1).get(rewards.get(runCounter-1).size()-1);
		}
	}
	
	
	/**
	 * @return All the rewards.
	 */
	public ArrayList<ArrayList<Double>> getRewards()
	{
		return rewards;
	}
	
	public ArrayList<Integer> getRunLengths()
	{
		ArrayList<Integer> lRunLengths = new ArrayList<Integer>();
		
		for(ArrayList<Double> lRewVec : rewards)
		{
			lRunLengths.add(lRewVec.size());
		}
		
		return lRunLengths;
	}

	/**
	 * Test whether reset performed on last iterations
	 * 
	 * @return Boolean representing whether reset performed
	 */
	public boolean resetPerformed()
	{
		return stepCounter == 0;
	}

	/**
	 * Get the dimension of observation space
	 * 
	 * @return The size of the observations space
	 */
	public int getNumberObservations()
	{
		return validObs.size();
	}

	/**
	 * Returns an ArrayList of all valid action-observations pairs.
	 * Action-observation pairs are valid if they occur in training set.
	 * 
	 * @return
	 */
	public HashSet<ActionObservation> getValidActionObservationSet()
	{
		return validActObs;
	}

	/**
	 * Returns list of all possible actions in the domain.
	 * @return All possible actions in the domain. 
	 */
	public HashSet<Action> getActionSet()
	{
		return validActs;
	}

	/**
	 * Returns the set of (action-observation) trajectories used for training..
	 * 
	 * @return A ArrayList of ActionObservations representing the set of random runs. 
	 */
	public ArrayList<ArrayList<ActionObservation>> getTrainingData()
	{
		return data;
	}

	/**
	 * Returns a training run.
	 * 
	 * @param i Index of the training run.
	 * @return The training run.
	 */
	public ArrayList<ActionObservation> getTrainingRun(int i)
	{
		if(i >= getMaxNumberOfRuns())
		{
			throw new EnvironmentException("Index exceeds number of runs");
		}
		return data.get(i);
	}

	/**
	 * Returns the max number unique runs this DataSet can generate
	 * 
	 * @return Max number of unique runs this DataSet can generate. 
	 */
	public int  getMaxNumberOfRuns()
	{
		return data.size();
	}

	/**
	 * Returns the maximum number any valid observation integer ID
	 * can assume. This should be equal to or similar in size to the
	 * dimension of observations. 
	 * 
	 * @return Maximum integer ID that can be associated with an observation.
	 */
	public int getMaxObservationIntegerID()
	{
		return this.maxObsID;
	}

	/**
	 * Returns the maximum integer ID any valid action associated
	 * with this DataSet may have. Should be equal too or similar in
	 * size to the dimension of actions or observations. 
	 * 
	 * @return Maximum integer ID that can be associated with an action. 
	 */
	public int getMaxActionIntegerID()
	{
		return this.maxActID;
	}
}

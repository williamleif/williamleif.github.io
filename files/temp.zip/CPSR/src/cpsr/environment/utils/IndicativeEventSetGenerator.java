/*
 *   Copyright 2012 William Hamilton
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 */
package cpsr.environment.utils;

import java.util.HashSet;
import java.util.Random;
import java.util.TreeSet;
import java.util.ArrayList;

import cpsr.environment.DataSet;
import cpsr.environment.components.ActionObservation;
import cpsr.environment.components.IndicativeEvent;

/**
 * Used to generate sets of indicative events from 
 * DataSet for learning.
 * 
 * @author William Hamilton
 */
public class IndicativeEventSetGenerator 
{
	DataSet data;

	/**
	 * Creates IndicativeEventGenerator for specified DataSet.
	 * 
	 * @param data
	 */
	public IndicativeEventSetGenerator(DataSet data)
	{
		this.data = data;
	}

	/**
	 * Generates standard indicative events using specified max history length;
	 * 
	 * @param maxHistoryLength Max length of history.
	 * @return ArrayList of indicative events. 
	 */
	public ArrayList<IndicativeEvent> generateStandardIndicativeEvents(int maxHistoryLength)
	{
		ArrayList<ArrayList<ActionObservation>> trainingData = data.getTrainingData();
		ArrayList<IndicativeEvent> indEvents  = new ArrayList<IndicativeEvent>();
		HashSet<ArrayList<ActionObservation>> historiesAdded = new HashSet<ArrayList<ActionObservation>>();
		for(ArrayList<ActionObservation> run : trainingData)
		{
			for(int i = 1; i < run.size() && i < maxHistoryLength; i++)
			{
				ArrayList<ActionObservation> history = new ArrayList<ActionObservation>(run.subList(0, i));
				if(!historiesAdded.contains(history))
				{
					addHistory(indEvents, history);
					historiesAdded.add(history);
				}
			}
		}
		return indEvents;
	}
	
	/**
	 * Generates standard indicative events using specified set size. 
	 * If set size is greater than one, the sets are constructed in a 
	 * random manner.
	 * 
	 * @param setSize Size of sets of histories.
	 * @return ArrayList of indicative events. 
	 */
	public ArrayList<IndicativeEvent> generateStandardIndicativeEvents()
	{
		return generateStandardIndicativeEvents(Integer.MAX_VALUE);
	}

	/**
	 * Generates set of suffix-history indicative events using specified
	 * set size, histories of all lengths, and all training data. 
	 * (Note: use with suffix history compatible estimators)
	 * 
	 * @param setSize Size of sets.
	 * @return
	 */
	public ArrayList<IndicativeEvent> generateSuffixHistoryIndicativeEvents()
	{
		return generateSuffixHistoryIndicativeEvents(Integer.MAX_VALUE);
	}


	/**
	 * Generates set of suffix-history indicative events using specified
	 * max history length, training runs, and set size.
	 * (Note: use with suffix history compatible estimators)
	 * 
	 * @param setSize Size of sets.
	 * @param maxHistoryLength Maximum length of a history.
	 * @return ArrayList of indicative events
	 */
	public ArrayList<IndicativeEvent> generateSuffixHistoryIndicativeEvents(int maxHistoryLength)
	{
		ArrayList<ArrayList<ActionObservation>> trainingData = data.getTrainingData();
		ArrayList<IndicativeEvent> indEvents  = new ArrayList<IndicativeEvent>();
		HashSet<ArrayList<ActionObservation>> historiesAdded = new HashSet<ArrayList<ActionObservation>>();

		for(ArrayList<ActionObservation> run : trainingData)
		{
			int i = 0;
			int j = 0;
			while(i < run.size())
			{
				j = i+1;
				while(j < i + maxHistoryLength + 1 && j < run.size())
				{
					ArrayList<ActionObservation> history = new ArrayList<ActionObservation>(run.subList(i, j));
					if(!historiesAdded.contains(history))
					{
						addHistory(indEvents, history);
						historiesAdded.add(history);
					}
					j++;
				}
				i++;
			}
		}
		return indEvents;
	}

	/**
	 * Helper method adds history to set of indicative events.
	 * 
	 * @param indEvents The set of indicative events.
	 * @param history History to add.
	 */
	private void addHistory(ArrayList<IndicativeEvent> indEvents, ArrayList<ActionObservation> history)
	{
		IndicativeEvent tempIndEvent;
		tempIndEvent = new IndicativeEvent();
		tempIndEvent.addHistory(history);
		indEvents.add(tempIndEvent.copy());
	}

}

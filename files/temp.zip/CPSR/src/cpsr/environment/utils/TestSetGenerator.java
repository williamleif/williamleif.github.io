/*
 *   Copyright 2012 William Hamilton
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 */
package cpsr.environment.utils;

import java.util.ArrayList;

import cpsr.environment.DataSet;
import cpsr.environment.components.ActionObservation;

/**
 * Classes generates list of tests using information from a DataSet.
 *
 * @author William Hamilton
 */
public class TestSetGenerator {
	DataSet data;
	
	/**
	 * Constructs test generator for a DataSet.
	 * 
	 * @param data The DataSetdata
	 */
	public TestSetGenerator(DataSet data)
	{
		this.data = data;
	}
	
	/**
	 * Returns a test set for this DataSet generated using
	 * all training data and tests of all possible lengths.
	 * @return ArrayList of ArrayLists of action-observation pairs.
	 * Each ArrayList is a test. 
	 */
	public ArrayList<ArrayList<ActionObservation>> generateTestSet()
	{
		return generateTestSet(Integer.MAX_VALUE-1);
	}
	
	/**
	 * Returns a test set for this DataSet
	 * @param maxTestLength Maximum length of test.
	 * @return ArrayList of ArrayLists of action-observation pairs.
	 * Each ArrayList is a test. 
	 */
	public ArrayList<ArrayList<ActionObservation>> generateTestSet(int maxTestLength)
	{
		return createTestSet(maxTestLength, data.getTrainingData());
	}
	
	/**
	 * Creates test sets from training data.
	 * Called by overloaded public generateTestSet methods.
	 * 
	 * @param maxTestLength Max length of test.
	 * @param trainingData Data used for construction of tests.
	 * @return ArrayList of test (which are ArrayLists of ActionObservations)
	 */
	private ArrayList<ArrayList<ActionObservation>> createTestSet(int maxTestLength, 
			ArrayList<ArrayList<ActionObservation>> trainingData)
	{
		ArrayList<ActionObservation > test;
		ArrayList<ArrayList<ActionObservation>> tests = new ArrayList<ArrayList<ActionObservation>>();
		
		for(ArrayList<ActionObservation> run : trainingData)
		{
			int i = 0;
			int j = 0;
			while(i < run.size())
			{
				j = i +1;
				while(j < i + maxTestLength + 1 && j-1 < run.size())
				{
					test = new ArrayList<ActionObservation>(run.subList(i, j));
					if(!tests.contains(test)) tests.add(test);
					j++;
				}
				i++;
			}
		}
		System.out.println(tests.size());
		return tests;
	}
}

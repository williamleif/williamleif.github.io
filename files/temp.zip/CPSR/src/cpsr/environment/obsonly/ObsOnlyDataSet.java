/*
 *   Copyright 2012 William Hamilton
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 */

package cpsr.environment.obsonly;

import java.util.ArrayList;
import java.util.HashSet;

import cpsr.environment.DataSet;
import cpsr.environment.components.Action;
import cpsr.environment.components.ActionObservation;
import cpsr.environment.components.Observation;
import cpsr.environment.components.ResetActionObservation;
import cpsr.environment.exceptions.EnvironmentException;

/**
 * Class for encapsulating observation only data (ie HMM-style environments).
 * Any attempt to access rewards will generate error.
 * All "Actions" in the DataSet must be DummyActions.
 * 
 * @author William Hamilton
 */
@SuppressWarnings("serial")
public class ObsOnlyDataSet extends DataSet 
{
	/**
	 * Constructs DataSet object from ArrayList of training runs, where
	 * each training run is a ArrayList of only observations. 
	 * Use for environments where only model learning and no planning
	 * (i.e. HMM-style domains) is necessary.
	 * Constructor will append DummyActions to observations for compatibility.
	 * Any attempt to plan with the data set or access rewards will generate error.
	 * 
	 * NOTE: Method names will still refer to actions; however, these actions
	 * are all DummyActions and will have no effect on learning a model of the
	 * environment.
	 * 
	 * @param data The list of action and observations
	 * @param obs Set of all valid observations in the domain associated with data set.
	 * @param maxObsID maximum ID of action in the domain associated with data set.
	 * (Note: must be one to one correspondence between these two objects).
	 */
	public ObsOnlyDataSet(ArrayList<ArrayList<Observation>> obData,  
			HashSet<Observation> obs, int maxObsID)
	{
		this.data = new ArrayList<ArrayList<ActionObservation>>();
		this.validActObs = new HashSet<ActionObservation>();
		this.validObs = new HashSet<Observation>();
		this.maxObsID = maxObsID;
		DummyAction act = new DummyAction(this);

		int i = 0;
		for(ArrayList<Observation> run: obData)
		{
			data.add(new ArrayList<ActionObservation>());
			for(Observation ob : run)
			{
				ob.setData((DataSet)this);
				ActionObservation actob = new ActionObservation(act, ob);
				this.data.get(i).add(actob);
				this.validActObs.add(actob);
				this.validObs.add(ob);
			}
			this.data.get(i).add(new ResetActionObservation((DataSet)this));
			i++;
		}	
		
		this.validActs = new HashSet<Action>();
		this.validActs.add(act);
	
		this.rewards = new ArrayList<ArrayList<Double>>();
		this.maxActID = 0;
	}
	
	/**
	 * Constructs DataSet object from ArrayList of training runs, where
	 * each training run is a ArrayList of only observations. 
	 * Use for environments where only model learning and no planning
	 * (i.e. HMM-style domains) is necessary.
	 * Constructor will append DummyActions to observations for compatibility.
	 * Any attempt to plan with the data set or access rewards will generate error.
	 * 
	 * NOTE: Method names will still refer to actions; however, these actions
	 * are all DummyActions and will have no effect on learning a model of the
	 * environment.
	 * 
	 * @param data The list of action and observation.
	 * (Note: must be one to one correspondence between these two objects).
	 */
	public ObsOnlyDataSet(ArrayList<ArrayList<Observation>> obData)
	{
		this.data = new ArrayList<ArrayList<ActionObservation>>();
		this.validActObs = new HashSet<ActionObservation>();
		this.validObs = new HashSet<Observation>();
		this.maxObsID = Integer.MIN_VALUE;
		this.maxActID = 0;
		DummyAction act = new DummyAction(this);

		int i = 0;
		for(ArrayList<Observation> run: obData)
		{
			data.add(new ArrayList<ActionObservation>());
			for(Observation ob : run)
			{
				if(ob.getID()>maxObsID) maxObsID = ob.getID();
				ob.setData((DataSet)this);
				ActionObservation actob = new ActionObservation(act, ob);
				this.data.get(i).add(actob);
				this.validActObs.add(actob);
				this.validObs.add(ob);
			}
			this.data.get(i).add(new ResetActionObservation((DataSet)this));
			i++;
		}	
		
		this.validActs = new HashSet<Action>();
		this.validActs.add(act);
	
		this.rewards = new ArrayList<ArrayList<Double>>();
		
	}
	
	@Override
	public double getReward()
	{
		throw new EnvironmentException("This is an observation only environment" +
				". There are no rewards!!.");
	}
	
	
}

/*
 *   Copyright 2012 William Hamilton
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 */
package cpsr.environment.obsonly.slam;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;

import cpsr.environment.components.Observation;
import cpsr.environment.obsonly.ObsOnlyDataSet;

/**
 * Constructs DataSet for SLAM learning using data provided by
 * EMBER project at CMU.
 * In this case, the distance to the beacons are thresholded as 
 * either present or not present, and observations are encoded
 * as a 24-bit binary vector, with each bit representing whether
 * a beacon was sensed in one of four directions within a time
 * window.
 * Data generated is used to predict the presence of beacons in
 * cardinal directions. 
 * 
 * @author William Hamilton
 */
public class SimpleThresholdSlam 
{
	protected ObsOnlyDataSet data;
	protected HashSet<Observation> validObs;
	protected ArrayList<ArrayList<Observation>> obs;
	int maxObsID;
	
	/**
	 * Generates data set from file.
	 * 
	 * @param fileName Name of file containing SLAM data.
	 * @param timeWindow Size of time window (in seconds, decimal
	 * values acceptable).
	 * @return DataSet for learning PSR.
	 */
	public ObsOnlyDataSet generateDataSet(String fileName, double timeWindow, double distanceThreshold)
	{
	    obs = new ArrayList<ArrayList<Observation>>();
		obs.add(new ArrayList<Observation>());
		Random rando = new Random();
		rando.setSeed(1155000);
		maxObsID = 0;
		try
		{
			double timeMark = 0;
			boolean firstIt = true;
			boolean timeExceeded = false;
			int[] obInfo = new int[38];
			BufferedReader reader = new BufferedReader(new FileReader(fileName));
			while(reader.ready())
			{
				String currentLine = reader.readLine();
				String[] stepInfo = currentLine.split(" ");
				double currentTime = Double.parseDouble(stepInfo[0]);
				if(firstIt)
				{
					timeMark = currentTime;
					firstIt = false;
				}
				else
				{
					timeExceeded = checkTimeWindowExceeded(currentTime, timeMark, timeWindow);
					timeMark = timeExceeded ? timeMark+timeWindow : timeMark;
				}
				addStepInfoToObInfo(obInfo, stepInfo, (rando.nextGaussian()*5+distanceThreshold));

				if(timeExceeded)
				{
					addObservationToDataSet(obInfo);
					obInfo = new int[38];
				}
			}
		}
		catch(IOException ex)
		{
			ex.printStackTrace();
		}
		data = new ObsOnlyDataSet(obs, validObs, maxObsID);
		return data;
	}
	
	/**
	 * Tests if time window exceeded.
	 * 
	 * @param currentTime
	 * @param timeMark
	 * @param timeWindow
	 * @return New time mark.
	 */
	protected boolean checkTimeWindowExceeded(double currentTime, double timeMark, double timeWindow)
	{
		double diff = currentTime - timeMark;
		if(diff > timeWindow)
		{
			return true;
		}
		return false;
	}
	
	/**
	 * Adds step info (i.e. presence of beacon) to binary int
	 * array containing info for creating an observation.
	 * 
	 * @param obInfo
	 * @param stepInfo
	 * @param distanceThreshold
	 */
	protected void addStepInfoToObInfo(int[] obInfo, String[] stepInfo, double distanceThreshold)
	{
		if(Double.parseDouble(stepInfo[3]) > distanceThreshold) return;
		
		int beacon = (int)(Double.parseDouble(stepInfo[2])-66800);
		int direction = (int)(Double.parseDouble(stepInfo[1]));
						
			if(beacon == 17)
			{
				obInfo[0+direction] = 1;
			}
			if(beacon == 21)
			{
				obInfo[4+direction] = 1;
			}
			if(beacon == 23)
			{
				obInfo[8+direction] = 1;
			}
			if(beacon == 26)
			{
				obInfo[12+direction] = 1;
			}
			if(beacon == 29)
			{
				obInfo[16+direction] = 1;
			}
			if(beacon == 32)
			{
				obInfo[20+direction] = 1;
			}
			if(beacon == 33)
			{
				obInfo[24+direction] = 1;
			}
			if(beacon == 34)
			{
				obInfo[28+direction] = 1;
			}
			if(beacon == 37)
			{
				obInfo[32+direction] = 1;
			}
			if(beacon == 38)
			{
				obInfo[34+direction] = 1;
			}
		
		}
	
	/**
	 * Adds an observation to data set using binary int
	 * array information.
	 * 
	 * @param obInfo Binary int array.
	 */
	public void addObservationToDataSet(int[] obInfo)
	{
		Observation ob = new SimpleThresholdSlamObservation(obInfo, data);
		maxObsID = Math.max(maxObsID, ob.getID());
		obs.get(0).add(ob);
	}
	

}

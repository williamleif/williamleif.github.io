package cpsr.environment.obsonly.slam;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;

import cpsr.environment.components.Observation;
import cpsr.environment.obsonly.ObsOnlyDataSet;

public class SimpleThresholdSlamNoDirection extends SimpleThresholdSlam 
{
	@Override
	public ObsOnlyDataSet generateDataSet(String fileName, double timeWindow, double distanceThreshold)
	{
		obs = new ArrayList<ArrayList<Observation>>();
		obs.add(new ArrayList<Observation>());
		validObs = new HashSet<Observation>();
		Random rando = new Random();
		rando.setSeed(1155000);
		try
		{
			double timeMark = 0;
			boolean firstIt = true;
			boolean timeExceeded = false;
			int[] obInfo = new int[12];
			BufferedReader reader = new BufferedReader(new FileReader(fileName));
			while(reader.ready())
			{
				String currentLine = reader.readLine();
				String[] stepInfo = currentLine.split(",");
				double currentTime = Double.parseDouble(stepInfo[0]);
				if(firstIt)
				{
					timeMark = currentTime;
					firstIt = false;
				}
				else
				{
					timeExceeded = checkTimeWindowExceeded(currentTime, timeMark, timeWindow);
					timeMark = timeExceeded ? timeMark+timeWindow : timeMark;
				}
				addStepInfoToObInfo(obInfo, stepInfo, (rando.nextGaussian()*5+distanceThreshold));

				if(timeExceeded)
				{
					addObservationToDataSet(obInfo);
					obInfo = new int[12];
				}
			}
		}
		catch(IOException ex)
		{
			ex.printStackTrace();
		}
		data = new ObsOnlyDataSet(obs);
		return data;
	}

	public ObsOnlyDataSet generateDataSet(ArrayList<ArrayList<String>> info, double timeWindow, double distanceThreshold)
	{
		obs = new ArrayList<ArrayList<Observation>>();
		validObs = new HashSet<Observation>();
		Random rando = new Random();
		rando.setSeed(1155000);

		double timeMark = 0;
		boolean firstIt = true;
		boolean timeExceeded = false;
		int[] obInfo = new int[12];
		for(int i = 0; i < info.size();i++)
		{
			obs.add(new ArrayList<Observation>());

			for(int j = 0; j < info.get(i).size(); j++)
			{
				String currentLine = info.get(i).get(j);
				String[] stepInfo = currentLine.split(",");
				double currentTime = Double.parseDouble(stepInfo[0]);
				if(firstIt)
				{
					timeMark = currentTime;
					firstIt = false;
				}
				else
				{
					timeExceeded = checkTimeWindowExceeded(currentTime, timeMark, timeWindow);
					timeMark = timeExceeded ? timeMark+timeWindow : timeMark;
				}
				addStepInfoToObInfo(obInfo, stepInfo, (rando.nextGaussian()*5+distanceThreshold));

				if(timeExceeded)
				{
					Observation ob = new SimpleThresholdSlamObservation(obInfo, data);
					maxObsID = Math.max(maxObsID, ob.getID());
					obs.get(i).add(ob);
					obInfo = new int[12];
				}
			}
		}

		data = new ObsOnlyDataSet(obs);
		return data;
	}


	@Override
	protected void addStepInfoToObInfo(int[] obInfo, String[] stepInfo, double distanceThreshold)
	{
		if(Double.parseDouble(stepInfo[3]) > 80) return;

		int beacon = (int)(Double.parseDouble(stepInfo[2])-82400);

		if(beacon == 18)
		{
			obInfo[Double.parseDouble(stepInfo[3]) < 30 ? 0 : 1] = 1;
		}
		if(beacon == 22)
		{
			obInfo[Double.parseDouble(stepInfo[3]) < 30 ? 2 : 3] = 1;
		}
		if(beacon == 24)
		{
			obInfo[Double.parseDouble(stepInfo[3]) < 30 ? 4 : 5] = 1;
		}
		if(beacon == 26)
		{
			obInfo[Double.parseDouble(stepInfo[3]) < 30 ? 6 : 7] = 1;
		}
		if(beacon == 31)
		{
			obInfo[Double.parseDouble(stepInfo[3]) < 30 ? 8 : 9] = 1;
		}
		if(beacon == 59)
		{
			obInfo[Double.parseDouble(stepInfo[3]) < 30 ? 10 : 11] = 1;
		}

	}
}

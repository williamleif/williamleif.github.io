/*
 *   Copyright 2012 William Hamilton
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 */
package cpsr.environment.obsonly.slam;

import cpsr.environment.DataSet;
import cpsr.environment.components.Observation;

/**
 * Observation associated with SimpleThresholdSlam.
 * Each observation is defined by a 24-bit binary string.
 * Each position of the binary string represents whether
 * a beacon was sensed in one of the four cardinal directions
 * during a time window (e.g. a 1 in the second position means
 * that beacon 1 was sensed in direction 2, i.e. East).
 * Binary representation converted to integer during learning. 
 * 
 * @author William Hamilton
 */
@SuppressWarnings("serial")
public class SimpleThresholdSlamObservation extends Observation 
{
	
	/**
	 * Constructs object from binary array of ints.
	 * NOTE: int array must contain only ones and zeroes.
	 * 
	 * @param obInfo int array of ones and zeroes.
	 */
	public SimpleThresholdSlamObservation(int[] obInfo, DataSet data)
	{
		this.id = 0;
		for(int i = 0; i < obInfo.length; i++)
		{
			if(obInfo[i] == 1) id += Math.pow(2,i);
		}
		this.dataSet = data;
	}
	
}

/*
 *   Copyright 2012 William Hamilton
 *
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 */
package cpsr.planning;

import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;

import cpsr.environment.DataSet;
import cpsr.environment.simulation.ISimulator;
import cpsr.environment.simulation.domains.Follow;
import cpsr.environment.utils.IndicativeEventSetGenerator;
import cpsr.environment.utils.TestSetGenerator;
import cpsr.model.PSR;
import cpsr.planning.ertapprox.actionensembles.ActionERTQPlanner;
import cpsr.planning.ertapprox.singleensemble.SingleEnsembleERTQPlanner;
import cpsr.planning.exceptions.PSRPlanningException;
import cpsr.stats.Basic;
import cpsr.stats.PlanningStats;

/**
 * Runs a standard PSR planning experiment with parameters in a property file.
 * 
 * @author William Hamilton
 */
public class StandardPSRPlanningExperiment 
{
	
	private ISimulator aSimulator;
	
	private int aSVDDim, aProjDim, aPolicyIter, aRunsPerIter, aMaxTestLen, aMaxRunLength,
	     aNumTreeSplits, aLeafSize, aNumTrees, aTreeIters, aMaxHistLen, aTestRuns;
	
	private double aEpsilon, aDiscount, aAvDiscReward, aRandAvDiscReward, aVarDiscReward;
	
	private String aPlanningType;
	
	private Properties aPSRProperties, aPlannerProperties;
	
	private DataSet aTestResults, aRandResults;
	
	private ArrayList<DataSet> aAllResults;

	
	private static int aSeed = 1234567;
	
	
	public static void main(String args[])
	{
		StandardPSRPlanningExperiment followExperiment = new StandardPSRPlanningExperiment("PSRConfigs/follow", "PlanningConfigs/follow", new Follow(aSeed));
		followExperiment.runExperiment();
		followExperiment.writeResultsSummaryToConsole();
		Basic.serializeDataSet(followExperiment.getTestResults(), "prelim_follow");
		Basic.serializeDataSet(followExperiment.getRandomPolicyResults(), "rand_follow");
	}

	/**
	 * Constructs a planning experiment.
	 * 
	 * @param pPSRConfigFile 
	 * @param pPlanningConfigFile
	 * @param pSimulator
	 */
	public StandardPSRPlanningExperiment(String pPSRConfigFile, String pPlanningConfigFile, ISimulator pSimulator)
	{
		aPSRProperties = new Properties();
		aPlannerProperties = new Properties();
		
		aSimulator = pSimulator;
		
		try
		{
			aPSRProperties.load(new FileReader("/home/ml/whamil3/workspace/CPSR/"+pPSRConfigFile));
			aPlannerProperties.load(new FileReader("/home/ml/whamil3/workspace/CPSR/"+pPlanningConfigFile));
			
			//getting PSR parameters.
			aSVDDim = Integer.parseInt(aPSRProperties.getProperty("SVD_Dimension", "-1"));
			aProjDim = Integer.parseInt(aPSRProperties.getProperty("Projection_Dimension", "-1"));
			aMaxTestLen = Integer.parseInt(aPSRProperties.getProperty("Max_Test_Length", "-1"));
			aMaxHistLen = Integer.parseInt(aPSRProperties.getProperty("Max_History_length", "-1"));
			
			//getting planning parameters
			aPlanningType = aPlannerProperties.getProperty("Ensemble_Type", "Action");
			aEpsilon = Double.parseDouble(aPlannerProperties.getProperty("Epsilon", "0.1"));
			aNumTreeSplits = Integer.parseInt(aPlannerProperties.getProperty("Num_Tree_Splits", "-1"));
			aRunsPerIter = Integer.parseInt(aPlannerProperties.getProperty("Runs_Per_Iteration"));
			aLeafSize = Integer.parseInt(aPlannerProperties.getProperty("Leaf_Size", "5"));
			aNumTrees = Integer.parseInt(aPlannerProperties.getProperty("Trees_Per_Ensemble", "30"));
			aTreeIters = Integer.parseInt(aPlannerProperties.getProperty("Tree_Building_Iterations", "50"));
			aPolicyIter = Integer.parseInt(aPlannerProperties.getProperty("Planning_Iterations", "1"));
			aTestRuns = Integer.parseInt(aPlannerProperties.getProperty("Test_Runs", "1000"));
			aDiscount = Double.parseDouble(aPlannerProperties.getProperty("Discount_Factor", "0.9"));
			aMaxRunLength = Integer.parseInt(aPlannerProperties.getProperty("Max_Run_Length", "-1"));
			if(aMaxRunLength == -1) aMaxRunLength = Integer.MAX_VALUE;
			
		}
		catch(IOException ex)
		{
			ex.printStackTrace();
		}
	}
	
	/**
	 * Runs an experiment and returns the DataSet of test results. 
	 * 
	 * @return Test results;
	 */
	public DataSet runExperiment()
	{
		TestSetGenerator lTestGen;
		IndicativeEventSetGenerator lIndEventGen;
		PSR lPSRModel;
		APSRPlanner lPlanner = null;
		String lPSRType;
		
		aSimulator.setMaxRunLength(aMaxRunLength);
		
		DataSet lTrainData = aSimulator.runSimulator(aRunsPerIter);
		
		aRandResults = lTrainData;
		aAllResults = new ArrayList<DataSet>();
		aRandAvDiscReward = PlanningStats.getAverageDiscountedReward(lTrainData, aDiscount);
				
		if(aProjDim == -1)
		{
			lPSRType = "TPSR";
		}
		else if(aSVDDim == -1)
		{
			lPSRType = "CPSR";
		}
		else
		{
			lPSRType = "Combined";
		}
		
		
		for(int i = 0; i < aPolicyIter; i++)
		{
			aAllResults.add(lTrainData);

			
			lTestGen = new TestSetGenerator(lTrainData);
			lIndEventGen = new IndicativeEventSetGenerator(lTrainData);
			aAllResults = new ArrayList<DataSet>();
			
			if(aMaxHistLen == -1)
			{
				lPSRModel = new PSR(lTrainData, lTestGen.generateTestSet(aMaxTestLen), 
						lIndEventGen.generateStandardIndicativeEvents(), lPSRType);
			}
			else
			{
				lPSRModel = new PSR(lTrainData, lTestGen.generateTestSet(aMaxTestLen), 
						lIndEventGen.generateStandardIndicativeEvents(aMaxHistLen), lPSRType);
			}
			
			lPSRModel.build(aRunsPerIter, aProjDim, aSVDDim);
			
			if(aPlanningType.equals("Action"))
			{
				lPlanner = new ActionERTQPlanner(lPSRModel);
			}
			else if(aPlanningType.equals("Single"))
			{
				lPlanner = new SingleEnsembleERTQPlanner(lPSRModel, lTrainData);
			}
			else
			{
				throw new PSRPlanningException("Unrecognized planner type.");
			}
			
			lPlanner.learnQFunction(lTrainData, aRunsPerIter, aTreeIters, aNumTreeSplits, aLeafSize,
					aNumTrees, aDiscount);
		
			if(i != aPolicyIter-1)
			{
				lTrainData = aSimulator.runSimulator(aRunsPerIter, new EpsilonGreedyPlanner(aSimulator.getRandomPlanner(aSeed), lPlanner, aEpsilon, aSeed));
			}
				

		}
		
		aTestResults = aSimulator.runSimulator(aTestRuns, lPlanner);
		
		aAllResults.add(aTestResults);
		
		aAvDiscReward = PlanningStats.getAverageDiscountedReward(aTestResults, aDiscount);
		
		aVarDiscReward = PlanningStats.getVarOfDiscountedReward(aTestResults, aDiscount, aAvDiscReward);
		
		
		return aTestResults;
	}
	
	/**
	 * @return Average reward obtained in a test.
	 */
	public double getAverageTestReward()
	{
		return aAvDiscReward;
	}
	
	/**
	 * @return Variance of test reward over runs.
	 */
	public double getVarianceOfTestReward()
	{
		return aVarDiscReward;
	}
	
	/**
	 * @return Average reward obtained by a random policy.
	 */
	public double getRandomPolicyAverageReward()
	{
		return aRandAvDiscReward;
	}
	
	/**
	 * @return DataSet of test results.
	 */
	public DataSet getTestResults()
	{
		return aTestResults;
	}
	
	/**
	 * @return Data Set of random policy results.
	 */
	public DataSet getRandomPolicyResults()
	{
		return aRandResults;
	}
	
	/**
	 * @return Results from all policy iterations (including first random results).
	 */
	public ArrayList<DataSet> getAllResults()
	{
		return aAllResults;
	}
	
	/**
	 * Writes summary of planning experiment to a file in results directory.
	 * @param pFileName Name of file.
	 */
	public void writeResultsSummaryToFile(String pFileName)
	{
		try
		{
			BufferedWriter lWriter = new BufferedWriter(new FileWriter("/home/ml/whamil3/workspace/CPSR/Results/"+pFileName));
			lWriter.write("PSR Properties:\n");
			lWriter.write(aPSRProperties.toString());
			lWriter.write("\nPlanning Properties:\n");
			lWriter.write(aPlannerProperties.toString());
			
			lWriter.write("\nResults:\n");
			lWriter.write("Average discounted reward: " + getAverageTestReward());
			lWriter.write("\nVariance of discounted reward of runs: "+getVarianceOfTestReward());
			lWriter.write("\nAverage length of run: "+PlanningStats.getAverageLengthOfRun(aTestResults));
			lWriter.write("\nAverage discounted reward obtained by random policy: "+getRandomPolicyAverageReward());
			lWriter.write("\nAverage length of random run: "+PlanningStats.getAverageLengthOfRun(aRandResults));
			lWriter.close();
		}
		catch(IOException ex)
		{
			ex.printStackTrace();
		}
	}
	
	/**
	 * Writes summary of planning experiment to console.
	 */
	public void writeResultsSummaryToConsole()
	{		
			System.out.print("PSR Properties:\n");
			System.out.print(aPSRProperties.toString());
			System.out.print("\nPlanning Properties:\n");
			System.out.print(aPlannerProperties.toString());
			
			System.out.print("\nResults:\n");
			System.out.print("Average discounted reward: " + getAverageTestReward());
			System.out.print("\nVariance of discounted reward of runs: "+getVarianceOfTestReward());
			System.out.print("\nAverage length of run: " + PlanningStats.getAverageLengthOfRun(aTestResults));
			System.out.print("\nAverage discounted reward obtained by random policy: "+getRandomPolicyAverageReward());
			System.out.print("\nAverage length of random run: "+PlanningStats.getAverageLengthOfRun(aRandResults));
	}
	
	
}

///*
// *   Copyright 2012 William Hamilton
// *
// *   Licensed under the Apache License, Version 2.0 (the "License");
// *   you may not use this file except in compliance with the License.
// *   You may obtain a copy of the License at
// *
// *       http://www.apache.org/licenses/LICENSE-2.0
// *
// *   Unless required by applicable law or agreed to in writing, software
// *   distributed under the License is distributed on an "AS IS" BASIS,
// *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// *   See the License for the specific language governing permissions and
// *   limitations under the License.
// */
//
//package cpsr.planning.utils;
//
//import java.util.ArrayList;
//
//import org.apache.commons.math3.stat.regression.OLSMultipleLinearRegression;
//
//import Jama.Matrix;
//import cpsr.environment.DataSet;
//import cpsr.environment.components.ActionObservation;
//import cpsr.model.PSR;
//import cpsr.planning.exceptions.PSRPlanningException;
//
//
///**
// * Class defines object used to estimate reward function. 
// * 
// * @author William Hamilton
// */
//public class RewardFunctionEstimator {
//	DataSet data;
//	PSR psr;
//	ArrayList<Double> rewards;
//	ArrayList<double[]> predictionVectors;
//	
//	/**
//	 * Constructs RewardFunctionEstimator using PSR and DataSet
//	 * 
//	 * @param psr The PSR used to learn the reward function. 
//	 * @param data The DataSet used in estimation. 
//	 * @throws PSRPlanningException
//	 */
//	public RewardFunctionEstimator(PSR psr, DataSet data) throws PSRPlanningException
//	{
//		if(psr.getDataSet().getClass() != data.getClass())
//		{
//			throw new PSRPlanningException("DataSets used to learn reward must be same type as one used to learn PSR");
//		}
//		this.psr = psr;
//		this.data = data; 
//	}
//	
//	/**
//	 * Top-level method for estimating reward function/parameters.
//	 * 
//	 * @param runs Number of training runs to use in estimation.
//	 * @return A vector (Jama Matrix) defining the linear reward function. 
//	 */
//	public Matrix estimateRewardFunction(int runs)
//	{
//		psr.resetToStartState();
//		
//		getRegressionData(runs);
//		
//		Matrix rewardParameter = performRegressionForRewards();
//		
//		return rewardParameter;
//	}
//
//	/**
//	 * Helper method performs regression to obtain reward parameters.
//	 * 
//	 * @return A vector determining the linear reward parameter function.
//	 */
//	private Matrix performRegressionForRewards()
//	{
//		double[][] trainingData = (double[][])predictionVectors.toArray();
//		double[] targetData = ArrayUtils.toPrimitive(((Double[])rewards.toArray()));
//		
//		OLSMultipleLinearRegression regressor = new OLSMultipleLinearRegression();
//		regressor.newSampleData(targetData, trainingData);
//		double[] betas = regressor.estimateRegressionParameters();
//		
//		Matrix rewardParameter = new Matrix(betas, betas.length);
//		
//		return rewardParameter;
//	}
//	
//	/**
//	 * Helper method gets the data used in regression
//	 * 
//	 * @param runs The number of runs used to get training samples.
//	 * (Note: in some DataSets if this is too large, runs will 
//	 * be repeated and redundant data will be obtained).
//	 */
//	private void getRegressionData(int runs)
//	{
//		int runCount = 1;
//
//		while(runCount < runs)
//		{
//			addData();
//			if(checkForReset()) runCount++;
//		}
//	}
//	
//	/**
//	 * Helper method adds data to training sample data structures
//	 */
//	private void addData()
//	{
//		ActionObservation actob = data.getNextActionObservation();
//		double reward = data.getReward();
//		
//		rewards.add(reward);
//		predictionVectors.add(psr.getPredictionVector().getVector().transpose().getArray()[0]);
//	}
//	
//	/**
//	 * Helper method determines if a run terminated..
//	 * If so, true returned and prediction vector reset. 
//	 * 
//	 * @return Boolean representing whether reset performed.
//	 */
//	private boolean checkForReset()
//	{
//		if(data.resetPerformed())
//		{
//			psr.resetToStartState();
//			return true;
//		}
//		else
//		{
//			return false;
//		}
//	}
//}

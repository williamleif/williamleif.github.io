package cpsr.planning;

import cpsr.environment.simulation.domains.Follow;
import cpsr.stats.Basic;

public class RunFollowExperiment {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		StandardPSRPlanningExperiment followExperiment = new StandardPSRPlanningExperiment("PSRConfigs/follow", "PlanningConfigs/follow", new Follow(12345));
		followExperiment.runExperiment();
		followExperiment.writeResultsSummaryToFile("test_follow");
		//Basic.serializeDataSet(followExperiment.getTestResults(), "follow_rand_results");
		//Basic.serializeDataSet(followExperiment.getRandomPolicyResults(), "follow_test_results");

	}

}

package cpsr.planning.ertapprox.averaged;

import java.util.ArrayList;

import cpsr.environment.components.Action;
import cpsr.model.PSR;
import cpsr.planning.IQFunction;
import cpsr.planning.ertapprox.actionensembles.ActionEnsemblesQFunction;

public class BayesAveragedActEnsQFunction implements IQFunction {

	private ArrayList<ActionEnsemblesQFunction> aQFuncts;
	private ArrayList<Double> aWeights;
	
	public BayesAveragedActEnsQFunction(ArrayList<ActionEnsemblesQFunction> pQFuncts, ArrayList<Double> pWeights)
	{
		aQFuncts = pQFuncts;
		aWeights = pWeights;
	}
	
	@Override
	public double getQValue(PSR psr, Action act) {
		
		double lQValue = 0.0;
		
		int i = 0;
		for(IQFunction lQFunct : aQFuncts)
		{
			lQValue += lQFunct.getQValue(psr, act)*aWeights.get(i);
		}
		
		return lQValue;
	}

}

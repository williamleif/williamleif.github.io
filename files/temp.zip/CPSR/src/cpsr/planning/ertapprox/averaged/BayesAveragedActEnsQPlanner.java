package cpsr.planning.ertapprox.averaged;

import java.util.ArrayList;
import java.util.Random;

import cpsr.environment.DataSet;
import cpsr.environment.components.ActionObservation;
import cpsr.environment.obsonly.ObsOnlyDataSet;
import cpsr.environment.simulation.domains.Follow;
import cpsr.environment.utils.IndicativeEventSetGenerator;
import cpsr.environment.utils.TestSetGenerator;
import cpsr.model.PSR;
import cpsr.model.Predictor;
import cpsr.model.averaging.BayesAveragedPSR;
import cpsr.model.averaging.BayesAveragedPredictor;
import cpsr.planning.APSRPlanner;
import cpsr.planning.IQFunction;
import cpsr.planning.ertapprox.actionensembles.ActionERTQPlanner;
import cpsr.planning.ertapprox.actionensembles.ActionEnsemblesQFunction;
import cpsr.stats.Basic;
import cpsr.stats.Likelihood;

public class BayesAveragedActEnsQPlanner extends APSRPlanner
{
	
	private DataSet aData;
	private BayesAveragedPSR aBPSR;
	private ArrayList<ActionERTQPlanner> aPlanners;
	private ArrayList<ActionEnsemblesQFunction> aQFunctions;
	
	
	public BayesAveragedActEnsQPlanner(BayesAveragedPSR pBPSR)
	{
		aBPSR = pBPSR; 
		
		aPlanners = new ArrayList<ActionERTQPlanner>();
		for(PSR lPSR : aBPSR.getPSRs())
		{
			aPlanners.add(new ActionERTQPlanner(lPSR));
		}
	}
	
	@SuppressWarnings("unchecked")
	public IQFunction learnQFunction(DataSet data, int runs, int iterations, int k, int nMin, int treesPerEnsemble, double pDiscount)
	{
		aQFunctions = new ArrayList<ActionEnsemblesQFunction>();
		for(ActionERTQPlanner lPlanner : aPlanners)
		{
			aQFunctions.add((ActionEnsemblesQFunction)lPlanner.learnQFunction(data, runs, iterations, treesPerEnsemble, k, nMin, pDiscount));
		}
		
		return new BayesAveragedActEnsQFunction(aQFunctions, aBPSR.getWeights());
	}
	
	@Override
	public void update(ActionObservation pAO)
	{
		for(PSR lPSR : aBPSR.getPSRs())
		{
			lPSR.update(pAO);
		}
	}
	
	@Override
	public void resetToStartState()
	{
		for(PSR lPSR : aBPSR.getPSRs())
		{
			lPSR.resetToStartState();
		}
	}
	
	
	public static void main(String args[])
	{
		Random testRando = new Random(100);
		
		ObsOnlyDataSet testData = (new Follow(testRando.nextInt())).runSimulatorObsOnly(1000, true, 20);
		double lambda = 0.1;
		
		ArrayList<Integer> projDims = new ArrayList<Integer>();
		ArrayList<Integer> svdDims = new ArrayList<Integer>();
		ArrayList<Double> priors = new ArrayList<Double>();
		for(int i = 7; i <= 20; i++)
		{
			for(int j = 0; j < 2; j++)
			{
				projDims.add(i);
				svdDims.add(i-1);
				priors.add(lambda*Math.exp(-lambda*i));
			}
		}
		
		ArrayList<Double> lTPSRLikes = new ArrayList<Double>();
		ArrayList<Double> lCPSRLikes = new ArrayList<Double>();
		ArrayList<Double> lBPSRLikes = new ArrayList<Double>();
		for(int i = 0; i < 10; i++)
		{
			ObsOnlyDataSet data = (new Follow(testRando.nextInt())).runSimulatorObsOnly(100, true, 15);
			IndicativeEventSetGenerator indGen = new IndicativeEventSetGenerator(data);

			TestSetGenerator testGen = new TestSetGenerator(data);

	//		PSR lTPSR = new PSR(data, testGen.generateTestSet(15), indGen.generateStandardIndicativeEvents(), "TPSR", "Standard", 15);
			PSR lCPSR = new PSR(data, testGen.generateTestSet(3), indGen.generateStandardIndicativeEvents(), "CPSR", "Standard", 10);
			BayesAveragedPSR lBPSR = new BayesAveragedPSR(data, testGen.generateTestSet(3), indGen.generateStandardIndicativeEvents(), "Standard", 10);
			
	//		lTPSR.build(100, 20, 20);
			lCPSR.build(100, 10,20);
			lBPSR.build(100, projDims, svdDims, priors);

	//		Likelihood lTPSRLiker = new Likelihood(lTPSR, testData, new Predictor(lTPSR));
	//		lTPSRLikes.add(lTPSRLiker.getObsOnlyLikelihoodOfData());
			
			Likelihood lCPSRLiker = new Likelihood(lCPSR, testData, new Predictor(lCPSR));
			lCPSRLikes.add(Math.log(lCPSRLiker.getLikelihoodOfData()));
			
			Likelihood lBPSRLiker = new Likelihood(lBPSR, testData, new BayesAveragedPredictor(lBPSR));
			lBPSRLikes.add(Math.log(lBPSRLiker.getLikelihoodOfData()));
			
		}

	//	System.out.println("TPSR: mean likelihood= "+Basic.mean(lTPSRLikes)+" std= "+Basic.std(lTPSRLikes));
		System.out.println("CPSR: mean likelihood= "+Basic.mean(lCPSRLikes)+" std= "+Basic.std(lCPSRLikes));
		System.out.println("BPSR: mean likelihood= "+Basic.mean(lBPSRLikes)+" std= "+Basic.std(lBPSRLikes));




	}

}

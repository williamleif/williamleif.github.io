package cpsr.planning;

import cpsr.environment.simulation.CassandraPOMDPSim;
import cpsr.stats.Basic;

public class RunWumpusExperiment {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CassandraPOMDPSim sim = new CassandraPOMDPSim(args[0], 13);
		StandardPSRPlanningExperiment cassandraExperiment = new StandardPSRPlanningExperiment("PSRConfigs/cass", "PlanningConfigs/cass", sim);
		cassandraExperiment.runExperiment();
		cassandraExperiment.writeResultsSummaryToFile("test_cass");
		//Basic.serializeDataSet(cassandraExperiment.getTestResults(), "cass_rand_data");
		//Basic.serializeDataSet(cassandraExperiment.getRandomPolicyResults(), "cass_test_data");	
		}

}
